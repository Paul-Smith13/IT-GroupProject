package events;

import akka.actor.ActorRef;
import com.fasterxml.jackson.databind.JsonNode;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.Card;
import structures.basic.Player;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.UnitAnimationType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

/**
 * Indicates that the user has clicked an object on
 * the game canvas, in this case a tile.
 * The event returns the x (horizontal) and y (vertical) indices of the tile that was
 * clicked. Tile indices start at 1.
 *
 * {
 *   messageType = “tileClicked”
 *   tilex = <x index of the tile>
 *   tiley = <y index of the tile>
 * }
 *
 * @author Dr. Richard McCreadie
 *
 */

public class TileClicked implements EventProcessor {
    private Unit selectedUnit = null; // Currently selected unit
    private Tile startTile = null; // Tile where the selected unit is located

    @Override
    public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
        int tilex = message.get("tilex").asInt();
        int tiley = message.get("tiley").asInt();

        if(gameState.getGameOver()) {
			BasicCommands.addPlayer1Notification(out, "Game is over! Please restart the game.", 5);
			return;
		}

        Tile clickedTile = GameState.tileGrid[tilex][tiley];
        Unit unit = clickedTile.getUnitFromTile();
        gameState.setClickedTile(clickedTile);

        if (gameState.isTrackingWraithlingSwarm()) {
        // If the game is tracking Wraithling Swarm spell, finish placing 3 wraithlings
            if (clickedTile.isOccupied()) {
                BasicCommands.addPlayer1Notification(out, "Must be placed on available tile.", 2);
                gameState.setClickedTile(null);
            } else {
                // Summon wraithling on available tile and reduce number of remaining wraithling
                gameState.summonWraithling(out, clickedTile); 
                gameState.reduceRemainingWraithlings();

                // Stop tracking Wraithing Swarm if placed all 3 wraithlings
                if (gameState.getRemainingWraithlings() == 0) {
                    gameState.setIsTrackingWraithlingSwarm(false);
                }
            }
        } else if (gameState.getSelectedCard() != null) {
        // Using Card logic
            Card selectedCard = gameState.getSelectedCard();
            if (selectedCard.isCreature()) {
                gameState.clearHighlight(out);
                processCreatureCard(out, selectedCard, clickedTile, gameState);
            } else {
                selectedCard.applySpell(out, gameState, unit);
                gameState.checkIfPlayerDeckEmpty(out, gameState);
            }
            gameState.setSelectedCard(null); // Reset selectedCard
        } else {
            checkTileForMoveAndAttackLogic(out, gameState, clickedTile);
        }
        gameState.setClickedTile(null);
    }


    // Check conditions before placing unit. Condition order: enough mana -> valid tile -> place unit 
    public void processCreatureCard(ActorRef out, Card selectedCard, Tile clickedTile, GameState gameState) {
        if (selectedCard.getManacost() > gameState.getCurrentPlayer().getMana()) {
            BasicCommands.addPlayer1Notification(out, "❌ Not enough mana to place the unit.", 2);
        } else if (!clickedTile.isValidToPlaceUnit(gameState)) {
            BasicCommands.addPlayer1Notification(out, "❌ Not valid tile to place unit.", 2);
        } else {
            Unit newUnit = gameState.placeUnit(out, gameState, clickedTile, selectedCard);
        }
    }
    

    public void checkTileForMoveAndAttackLogic(ActorRef out, GameState gameState, Tile clickedTile) {
        Unit unit = clickedTile.getUnitFromTile();

        // Click on the same unit to cancel the highlighting
        if (unit != null && unit == selectedUnit) {
            gameState.clearHighlight(out);
            selectedUnit = null;
            startTile = null;
            return;
        }
    
        // Select your unit and highlight the range of movement if unit is allowed to move
        if (unit != null && unit.getPlayer() == gameState.getCurrentPlayer() && !gameState.getNotMoveAndAttackSet().contains(unit)) {
            gameState.clearHighlight(out);
            selectedUnit = unit;
            startTile = clickedTile;
    
            highlightValidMoves(out, gameState, clickedTile);
            return;
        }
    
        // If you click on a space within range, perform a normal move.
        if (selectedUnit != null && gameState.getHighlightedTiles().contains(clickedTile)) {
            gameState.clearHighlight(out);
            selectedUnit.moveUnit(out, startTile, clickedTile, gameState);
            selectedUnit = null;
            startTile = null;
            return;
           
        }
    
        // Move Attack Logic (if clicking on an enemy unit and distance == 2 or 3)
        if (unit != null && selectedUnit != null && unit.getPlayer() != selectedUnit.getPlayer()) {
            int distance = startTile.calculateDistance(clickedTile);
        
            // Attack if adjacent
            if (distance == 1) {
                selectedUnit.attack(out, startTile, clickedTile, gameState);
                return;
            }
            // Move and attack (distance = 2)
            else if (distance == 2 ) {
                selectedUnit.moveAndAttack(out, startTile, clickedTile, gameState);
                try {Thread.sleep(1500); } catch (InterruptedException e) {e.printStackTrace();}
            } 
            else if (distance == 3) {
                if (isValidDistance3Attack(startTile, clickedTile)) {
                    selectedUnit.moveAndAttack(out, startTile, clickedTile, gameState);
                }
            }
            
            else if (distance == 4) {
                double euclideanDistance = Math.sqrt(Math.pow(startTile.getTilex() - clickedTile.getTilex(), 2) + Math.pow(startTile.getTiley() - clickedTile.getTiley(), 2));
                
                if (euclideanDistance <= 4) {
                    selectedUnit.moveAndAttack(out, startTile, clickedTile, gameState);
                } else {
                    BasicCommands.addPlayer1Notification(out, "❌Invalid attack: Target is too far!", 2);
                }
            }

            //reset the tile and units
            selectedUnit = null;
            startTile = null;
        }
        gameState.clearHighlight(out);
    }

    private boolean isValidDistance3Attack(Tile start, Tile end) {
        int dx = end.getTilex() - start.getTilex();
        int dy = end.getTiley() - start.getTiley();
    
        // Move 3 frames in a straight line
        if ((Math.abs(dx) == 3 && dy == 0) || (Math.abs(dy) == 3 && dx == 0)) {
            return true;
        }
    
        
        if ((Math.abs(dx) == 2 && Math.abs(dy) == 1) || (Math.abs(dx) == 1 && Math.abs(dy) == 2)) {
            return true;
        }
    
        return false; // Other paths are not allowed
    }

    
    // Range within which the highlighted unit can be moved
    private void highlightValidMoves(ActorRef out, GameState gameState, Tile selectedTile) { 
	    //US 8 - Flying Ability
    	if (selectedTile.getUnitFromTile().getUnitName().contains("Young Flamewing")) {
	    	Unit selectedUnit = selectedTile.getUnitFromTile();
	    	int x = selectedTile.getTilex();
	    	int y = selectedTile.getTiley();
	    	gameState.getHighlightedTiles().clear();
	    	gameState.getAttackTiles().clear();
	    	if(gameState.hasUnitMoved(selectedUnit)) {
	    		BasicCommands.addPlayer1Notification(out, "Young Flamewing already moved", 2);
	    		highlightAttackTiles(out,gameState,selectedTile);
	    		return;
	    	}
	    	
	    	for (int i = 0; i < 9; i++) {
	    		for (int j = 0; j < 5; j++) {
	    	    	Tile targetTile = gameState.getTileByCoordinates(i, j);
	    	    	Unit unit = targetTile.getUnitFromTile();
	    	    	if (unit == null) {
	                    BasicCommands.drawTile(out, targetTile, 1); 
	                    gameState.addHighlightedTile(targetTile);
	                }
	    		}
	    	}
	    	
	    }
	    else {

    		if (selectedTile == null || selectedTile.getUnitFromTile() == null) {
	            return;
	        }
	    
	        Unit selectedUnit = selectedTile.getUnitFromTile();
	        int x = selectedTile.getTilex();
	        int y = selectedTile.getTiley();
	    
	        // **clears previous highlighting**
	        gameState.getHighlightedTiles().clear();
	        gameState.getAttackTiles().clear();
	    
	        // **If the piece has already moved, skip the move highlighting and only show the attack range**
	        if (gameState.hasUnitMoved(selectedUnit)) {
	            BasicCommands.addPlayer1Notification(out, "Pieces have moved, only attack range shown",2);
	            highlightAttackTiles(out, gameState, selectedTile);
	            return;
	        }
	        
	        
	        // ** Pawn not moving, normal highlighting of move range **
	        int[][] moves = {
	            {1, 0}, {2, 0}, {-1, 0}, {-2, 0},  
	            {0, 1}, {0, 2}, {0, -1}, {0, -2},  
	            {1, 1}, {-1, 1}, {1, -1}, {-1, -1} 
	        };
	    
	        boolean blockRight = false, blockLeft = false;
	        boolean blockUp = false, blockDown = false;
	    
	        for (int[] move : moves) {
	            int newX = x + move[0];
	            int newY = y + move[1];
	    
	            if (newX < 0 || newX >= GameState.COLS || newY < 0 || newY >= GameState.ROWS) continue;
	    
	            Tile targetTile = gameState.getTileByCoordinates(newX, newY);
	            Unit unit = targetTile.getUnitFromTile();
	    
	            // Handle blocking logic
	            if (move[0] == 1 && move[1] == 0 && unit != null) blockRight = true;
	            if (move[0] == -1 && move[1] == 0 && unit != null) blockLeft = true;
	            if (move[0] == 0 && move[1] == 1 && unit != null) blockDown = true;
	            if (move[0] == 0 && move[1] == -1 && unit != null) blockUp = true;
	    
	            if ((blockRight && move[0] == 2 && move[1] == 0) ||
	                (blockLeft && move[0] == -2 && move[1] == 0) ||
	                (blockDown && move[0] == 0 && move[1] == 2) ||
	                (blockUp && move[0] == 0 && move[1] == -2)) {
	                continue;
	            }
	    
	            if (unit == null) {
	                BasicCommands.drawTile(out, targetTile, 1); 
	                gameState.addHighlightedTile(targetTile);
	            }
	        }
	    
	        // Calculation of the range of attack
	        List<Tile> highlightedTiles = new ArrayList<>(gameState.getHighlightedTiles());
	        List<Tile> attackableEnemies = getAttackableEnemiesFromTiles(gameState, highlightedTiles, selectedUnit.getPlayer());
	    
	        // Highlight only attackable enemy units.
	        for (Tile attackTile : attackableEnemies) {
	            BasicCommands.drawTile(out, attackTile, 2); 
	            gameState.addAttackTile(attackTile);
	        }
	    }
    }
    
//getAttackableEnemiesFromTiles to make the red tiles
private List<Tile> getAttackableEnemiesFromTiles(GameState gameState, List<Tile> moveTiles, Player currentPlayer) {
    List<Tile> attackableEnemyTiles = new ArrayList<>();
    int[][] attackRange = {
        {-1, -1}, {0, -1}, {1, -1},
        {-1, 0},           {1, 0},
        {-1, 1},  {0, 1},  {1, 1}
    };

    for (Tile moveTile : moveTiles) {
        for (int[] dir : attackRange) {
            int newX = moveTile.getTilex() + dir[0];
            int newY = moveTile.getTiley() + dir[1];

            if (newX >= 0 && newX < GameState.COLS && newY >= 0 && newY < GameState.ROWS) {
                Tile attackTile = gameState.getTileByCoordinates(newX, newY);

                if (attackTile != null) {
                    Unit enemyUnit = attackTile.getUnitFromTile();
                    if (enemyUnit != null && enemyUnit.getPlayer() != currentPlayer) {
                        attackableEnemyTiles.add(attackTile);
                    }
                }
            }
        }
    }

    return attackableEnemyTiles;
}
    //highlightAttackTiles method
    private void highlightAttackTiles(ActorRef out, GameState gameState, Tile selectedTile) {
        if (selectedTile == null || selectedTile.getUnitFromTile() == null) return; // Avoiding Null Pointer Exceptions

        // Get all AI units
        List<Unit> aiUnits = gameState.getAiPlayer().getAiUnits(gameState);

        int[][] directions = {
                {-1, -1}, {0, -1}, {1, -1},
                {-1, 0},  {1, 0},
                {-1, 1},  {0, 1},  {1, 1}
        };

        for (int[] dir : directions) {
            int newX = selectedTile.getTilex() + dir[0];  // Make sure you use the correct method name
            int newY = selectedTile.getTiley() + dir[1];

            // Ensure that the coordinates are legal
            if (gameState.isValidTile(newX, newY)) {
                Tile adjacentTile = gameState.getTileByCoordinates(newX, newY);
                Unit unitOnTile = adjacentTile.getUnitFromTile();

                // Highlight only the Tile where the AI unit is located.
                if (unitOnTile != null && aiUnits.contains(unitOnTile)) {
                    BasicCommands.drawTile(out, adjacentTile, 2); // 2 = red highlight
                    gameState.addAttackTile(adjacentTile);
                }
            }
        }
    }

    public boolean isValidTile(int x, int y) {
        return x >= 0 && x < GameState.COLS && y >= 0 && y < GameState.ROWS; 
    }      

}
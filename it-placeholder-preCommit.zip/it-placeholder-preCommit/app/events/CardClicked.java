package events;


import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import commands.BasicCommands;
import akka.actor.ActorRef;
import structures.GameState;
import structures.basic.Card;
import structures.basic.Player;
import structures.basic.Tile;

/**
 * Indicates that the user has clicked an object on the game canvas, in this case a card.
 * The event returns the position in the player's hand the card resides within.
 * 
 * { 
 *   messageType = “cardClicked”
 *   position = <hand index position [1-6]>
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class CardClicked implements EventProcessor{

	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		int handPosition = message.get("position").asInt();
		gameState.clearHighlight(out);

		if(gameState.getGameOver()) {
			BasicCommands.addPlayer1Notification(out, "Game is over! Please restart the game.", 5);
			return;
		}

		List<Card> currentPlayersCards = gameState.getCurrentPlayer().getCardsOnHand();
		Card selectedCard = currentPlayersCards.get(handPosition - 1);

		if (selectedCard != null) {
			// Set the currently selected card
			if(selectedCard.getManacost() > gameState.getCurrentPlayer().getMana()) {
				BasicCommands.addPlayer1Notification(out, "Not enough mana to use the card.", 2);
				return; 
			}

			gameState.setSelectedCard(selectedCard);
			
			// Highlight target tiles if it's a Spell card
			if (!selectedCard.isCreature()) {
				if (selectedCard.getCardname().equals("Wraithling Swarm")) {
					BasicCommands.addPlayer1Notification(out, "Choose 3 tiles to summon 3 wraithlings", 2);
				}
				gameState.highlightSpellTargets(out, selectedCard);
			}

			// Highlight valid tiles to summon unit if it's a Unit card
			if (selectedCard.isCreature()) {
				gameState.highlightSummonTiles(out);
			}
		}
	}
		
	}
	

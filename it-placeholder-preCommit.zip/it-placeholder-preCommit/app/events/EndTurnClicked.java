package events;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.Unit;
import structures.basic.Player;

/**
 * Indicates that the user has clicked an object on the game canvas, in this case
 * the end-turn button.
 * 
 * { 
 *   messageType = “endTurnClicked”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class EndTurnClicked implements EventProcessor{
	//US 15 - Paul - End Turn Clicked
	//US 25 - Paul - Reset Mana upon End Turn
	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		
		gameState.clearHighlight(out);
		gameState.reset();  // Reset the marks of units which is used to show they have moved
        gameState.AttackReset();
		gameState.resetStunnedUnits(); // Keep Stun's rounds down.about the spell stun
        gameState.resetUnitsummoned();

		if(gameState.getGameOver()) {
			BasicCommands.addPlayer1Notification(out, "Game is over! Please restart the game.", 5);
			return;
		}

		Player humanPlayer = gameState.getHumanPlayer();
		Player aiPlayer = gameState.getAiPlayer();
		Player currentPlayer = gameState.getCurrentPlayer();

		//Checks if it is Human Player's turn.
		if (currentPlayer == humanPlayer) {
			gameState.setplayer1Turn(false);
			BasicCommands.addPlayer1Notification(out, "Player 1 ended turn.", 5);
			humanPlayer.setMana(0);	
			BasicCommands.setPlayer1Mana(out, humanPlayer);	
			
			gameState.getHumanPlayer().drawCard(out, 1);
			for(Unit unit : humanPlayer.getAllUnits()){
				if(unit.hasMoved() || unit.hasAttacked()){
					unit.setMoved(false);
					unit.setAttacked(false);
				}
			}
			
			//US 25: when turn ended set player's mana to 0
			//GameState.aiPlayer.setMana(gameState.getHumanTurnCounter() + 1);		//US 4: For AI Player's Mana after Human Player ends their turn
			gameState.startAiTurn(out);


			//Need to increment HumanTurnCount after end turn clicked
			//gameState.setHumanTurnCount(gameState.getHumanTurnCounter() + 1);

		//Else if it is AI Player's turn	
		} else {
			//AI Commands to be called here. Need to know where AI Game Actor is to call anything.
			gameState.setplayer1Turn(true);
			BasicCommands.addPlayer1Notification(out, "Player 2 ended turn.", 5);
			aiPlayer.setMana(0);		
			BasicCommands.setPlayer2Mana(out, aiPlayer);									//US 25: when turn ended set player's mana to 0
			//GameState.humanPlayer.setMana(gameState.getHumanTurnCounter() + 1);		//US 4: For Human Player's Mana after AI Player ends their turn
			
			gameState.getAiPlayer().drawCard(out, 1);//US23  add card

			//set hasMoved and hasAttacked to false for all units
			for(Unit unit : aiPlayer.getAllUnits()){
				if(unit.hasMoved() || unit.hasAttacked()){
					unit.setMoved(false);
					unit.setAttacked(false);
				}
			}
			gameState.startHumanTurn(out);
			//Need to increment HumanTurnCount after end turn clicked
			//gameState.setAITurnCount(gameState.getAITurnCounter() + 1);
		}
	}
}

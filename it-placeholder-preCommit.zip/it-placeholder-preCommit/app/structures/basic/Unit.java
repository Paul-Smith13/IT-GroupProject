package structures.basic;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import commands.BasicCommands;
import structures.GameState;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
import akka.actor.ActorRef;
import java.util.*;

/**
 * This is a representation of a Unit on the game board.
 * A unit has a unique id (this is used by the front-end.
 * Each unit has a current UnitAnimationType, e.g. move,
 * or attack. The position is the physical position on the
 * board. UnitAnimationSet contains the underlying information
 * about the animation frames, while ImageCorrection has
 * information for centering the unit on the tile. 
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Unit {
	// Attributes
	@JsonIgnore
	protected static ObjectMapper mapper = new ObjectMapper(); // Jackson Java Object Serializer, is used to read java objects from a file
	@JsonIgnore  
	private Player player; 
	UnitAnimationType animation;
	Position position;
	UnitAnimationSet animations;
	ImageCorrection correction;
	int id, attack, health, maxHealth, stunnedTurns = 0, deadWatched = 0;
	private String unitAbility1, unitAbility2, unitName = "";
	public boolean moved, hasProvoke, attacked = false, martyr = false;
	private static int globalDeadWatched = 0;
	private int robustness = 0; // Only belongs to human avatar and is set to 3 if casted with Horn of The Forsaken

	// Constructors
	public Unit() {} 

	public Unit(int id, UnitAnimationSet animations, ImageCorrection correction) {
		this.id = id;
		this.animation = UnitAnimationType.idle;
		this.position = new Position(0, 0, 0, 0);
		this.correction = correction;
		this.animations = animations;
	}
	
	public Unit(int id, UnitAnimationSet animations, ImageCorrection correction, Tile currentTile) {
		this(id, animations, correction);
		this.position = new Position(currentTile.getXpos(), currentTile.getYpos(), currentTile.getTilex(), currentTile.getTiley());
	}
	
	public Unit(int id, UnitAnimationType animation, Position position, UnitAnimationSet animations, ImageCorrection correction) {
		this(id, animations, correction);
		this.animation = animation;
		this.position = position;
	}

	// Methods
	public Tile getTileFromUnit(GameState gameState) {
		return gameState.getTileByCoordinates(position.getTilex(), position.getTiley());
	}

	// Apply attack of unit at startTile to unit at endTile
	public void attack(ActorRef out, Tile startTile, Tile endTile, GameState gameState) {  
		Unit attacker = startTile.getUnitFromTile();    
		Unit target = endTile.getUnitFromTile();

		if (attacker == null || target == null) {
			BasicCommands.addPlayer1Notification(out, "❌ Invalid attack: Target is out of range or no unit found.", 2);
			return;
		}

		if (!isAdjacent(startTile, endTile)) {
			// If not adjacent, attempt to move and attack
			BasicCommands.addPlayer1Notification(out, "❌ Target is out of range. Attempting to move and attack...", 2);
			moveAndAttack(out, startTile, endTile, gameState);
			return;
		}

		if (gameState.hasUnitsummoned(attacker)) {
			BasicCommands.addPlayer1Notification(out, "❌ Unit cannot attack in the first turn!", 2);
			return;
		}
		if (attacker.isStunned()) {
			BasicCommands.addPlayer1Notification(out, "❌ Unit is stunned and cannot attack!", 2);
			return;
		}

		if (attacker.hasProvoke && !target.hasProvokeAbility()) {
			BasicCommands.addPlayer1Notification(out, "❌ Unit is provoked and cannot attack!", 2);
			return;
		}

		// Check if the target is within attack range
		int distance = startTile.calculateDistance(endTile);
		if (distance > 4) {
			BasicCommands.addPlayer1Notification(out, "❌ Target is out of attack range!", 2);
			return;
		}

		// If there is no unit on one of the clicked tiles

		// Players cannot control enemy units
		if (attacker.getPlayer() != gameState.getCurrentPlayer()) {
			BasicCommands.addPlayer1Notification(out, "❌ Invalid attack: Players cannot control enemy units.", 2);
			return;
		}

		// AI units cannot attack other AI units
		if (target.getPlayer() == gameState.getCurrentPlayer()) {
			BasicCommands.addPlayer1Notification(out, "❌ Cannot attack own units.", 2);
			return;
		}

		// Check if the target is adjacent
		if (!isAdjacent(startTile, endTile)) {
			BasicCommands.addPlayer1Notification(out, "❌ Invalid attack: Target is not adjacent!", 2);
			return;
		}

		if (gameState.hasUnitAttacked(attacker)) {
			BasicCommands.addPlayer1Notification(out, "❌ Already attacked, can't attack again!", 2);
			return;
		}
		
		// If attacker is human avatar with robustness > 0, summon Wraithling on a random
		// unoccupied adjacent tile. If no unoccupied tiles, return. (Horn of the Forsaken feature)
		if (attacker.isHumanAvatar() && attacker.getRobustness() > 0) {
			List<Tile> adjacentTiles = startTile.getUnocuppiedAdjacentTiles(gameState);
			if (!adjacentTiles.isEmpty()) {
				int randomIndex = (new Random()).nextInt(adjacentTiles.size());
				Tile chosenTile = adjacentTiles.get(randomIndex);
				summonWraithling(out, chosenTile, gameState);
			}
		}
	
		attacker.applyDamage(out, target, gameState);
		gameState.markUnitAsAttacked(attacker);

		if (target.getHealth() <= 0) {
			gameState.removeDeadUnit(out, target, endTile);
		} else {
			counterAttack(out, target, attacker, startTile, endTile, gameState);
		}
	}

	private void counterAttack(ActorRef out, Unit defender, Unit attacker, Tile attackerStartTile, Tile defenderEndTile, GameState gameState) {
		if (defender.getHealth() <= 0) return;

		BasicCommands.addPlayer1Notification(out, "CounterAttack！", 2);
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, defender, UnitAnimationType.attack));} catch (InterruptedException e) {e.printStackTrace();}
		int newHealth = attacker.getHealth() - defender.getAttack();
		attacker.setHealth(Math.max(newHealth, 0));
		BasicCommands.setUnitHealth(out, attacker, attacker.getHealth());

		if (attacker.isHumanAvatar()) {
			gameState.getHumanPlayer().updateAndDisplayHealth(out, attacker.getHealth());
			// Reduce robustness 
			if (attacker.getRobustness() > 0) {
				attacker.setRobustness(attacker.getRobustness() - 1);
			}
		} else if (attacker.isAiAvatar()) {
			gameState.getAiPlayer().updateAndDisplayHealth(out, attacker.getHealth());
			zealAbility(out, attacker, gameState);
		}

		if (attacker.getHealth() <= 0) {
			gameState.removeDeadUnit(out, attacker, attackerStartTile);
		} else {
			try {Thread.sleep(BasicCommands.playUnitAnimation(out, attacker, UnitAnimationType.idle));} catch (InterruptedException e) {e.printStackTrace();}
		}

		try {Thread.sleep(BasicCommands.playUnitAnimation(out, defender, UnitAnimationType.idle));} catch (InterruptedException e) {e.printStackTrace();}
		

	}

	// This method reduces the target unit health by attacker's attack 
	// and update player's health if the target is an avatar
	private void applyDamage(ActorRef out, Unit target, GameState gameState) {
		int damage = this.getAttack();
		target.setHealth(Math.max(target.getHealth() - damage, 0));
		BasicCommands.setUnitHealth(out, target, target.getHealth()); 
		try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
		attacked = true;
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, this, UnitAnimationType.attack));} catch (InterruptedException e) {e.printStackTrace();}
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, target, UnitAnimationType.hit));} catch (InterruptedException e) {e.printStackTrace();}
		BasicCommands.addPlayer1Notification(out, "⚔️ Attack executed!", 2);
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, this, UnitAnimationType.idle));} catch (InterruptedException e) {e.printStackTrace();}
		
		if (target.isHumanAvatar()) {
			gameState.getHumanPlayer().updateAndDisplayHealth(out, target.getHealth());
			if (target.getRobustness() > 0) target.setRobustness(target.getRobustness() - 1);
		} else if (target.isAiAvatar()) {
			gameState.getAiPlayer().updateAndDisplayHealth(out, target.getHealth());
			zealAbility(out, target, gameState);
		}
	}

	public void zealAbility(ActorRef out, Unit target, GameState gameState) {
		for (int i = 0; i < GameState.COLS; i++) {
			for (int j = 0; j < GameState.ROWS; j++) {
				Tile tileChecked = GameState.tileGrid[i][j];
				if (tileChecked != null) {
					Unit unitChecked = tileChecked.getUnitFromTile();
					if (unitChecked != null && unitChecked.getAbility1() != null && (unitChecked.getAbility1().contains("Zeal") || unitChecked.getUnitName().contains("Silverguard Knight"))) {
						unitChecked.setAttack(unitChecked.getAttack() + 2);
						try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
						BasicCommands.setUnitAttack(out, unitChecked, unitChecked.getAttack());
					}
				}
			}
		}
	}


	/**
	 * Checks if two tiles are adjacent (including diagonals).
	 */
	public boolean isAdjacent(Tile tile1, Tile tile2) {
		int dx = Math.abs(tile1.getTilex() - tile2.getTilex());
		int dy = Math.abs(tile1.getTiley() - tile2.getTiley());
		return (dx == 1 && dy == 0) || (dx == 0 && dy == 1) || (dx == 1 && dy == 1);
	}

	public void moveUnit(ActorRef out, Tile startTile, Tile endTile, GameState gameState) {
		if (!gameState.getGameOver()) {
			if (startTile == null || endTile == null || this == null) {
				BasicCommands.addPlayer1Notification(out, "❌ Invalid tiles or unit.", 2);
				return;
			}

			if (gameState.hasUnitsummoned(this)) {
				BasicCommands.addPlayer1Notification(out, "❌ Unit cannot move right after being summoned.", 2);
				return;
			}

			if (this.isStunned()) {
				BasicCommands.addPlayer1Notification(out, "❌ Unit is Stunned. Cannot move in this turn.", 2);
				return;
			}
			if (this.getPlayer() != gameState.getCurrentPlayer()) {
				BasicCommands.addPlayer1Notification(out, "❌ Cannot control enemy units.", 2);
				return;
			}
			
			if (gameState.hasUnitMoved(this)) {
				BasicCommands.addPlayer1Notification(out, "❌ Unit has already moved. Cannot move again!", 2);
				return;
			}

			if(this.hasProvoke){
				BasicCommands.addPlayer1Notification(out, "Unit is provoked, cannot move!", 2);
				return;
			}

			int dx = Math.abs(endTile.getTilex() - startTile.getTilex());
			int dy = Math.abs(endTile.getTiley() - startTile.getTiley());

			if (!this.getUnitName().contains("Young Flamewing") && !((dx <= 2 && dy == 0) || (dy <= 2 && dx == 0) || (dx == 1 && dy == 1))) {
				BasicCommands.addPlayer1Notification(out, "❌ Invalid move: out of range!", 2);
				return;
			}

			if (endTile.getUnitFromTile() != null) {
				BasicCommands.addPlayer1Notification(out, "❌ Target grid is occupied!", 2);
				return;
			}

			boolean yFirst = hasUnitAt(startTile.getTilex() - 1, startTile.getTiley()) || hasUnitAt(startTile.getTilex() + 1, startTile.getTiley());

			if (yFirst && isPathBlocked(startTile, endTile)) {
				yFirst = false;
			}

			if (!this.getUnitName().contains("Young Flamewing") && !yFirst && isPathBlocked(startTile, endTile)) {
				BasicCommands.addPlayer1Notification(out, "❌ All paths are blocked!", 2);
				return;
			}

			if (this.hasProvokeAbility()) {
				removeProvokeAbility(startTile, gameState);
			}

			move(out, this, startTile, endTile, yFirst);
			gameState.markUnitAsMoved(this);

			List<Unit> neighbourUnits = getNeighbourUnits(gameState, endTile);
			for (Unit unit : neighbourUnits) {
				if (unit.hasProvokeAbility()) {
					unit.applyProvokeAbility(unit.getTileFromUnit(gameState), gameState);
				}
			}

			if (this.hasProvokeAbility()) {
				applyProvokeAbility(endTile, gameState);
			}
		}
	}

	public Unit findBestAttackTarget(GameState gameState) {
		List<Unit> enemyUnits = gameState.getHumanPlayer().getAllUnits();
		Unit bestTarget = null;
		int highestPriority = Integer.MIN_VALUE;

		for (Unit enemy : enemyUnits) {
			int priority = calculateAttackPriority(enemy);
			if (priority > highestPriority) {
				highestPriority = priority;
				bestTarget = enemy;
			}
		}

		return bestTarget;
	}

	private int calculateAttackPriority(Unit enemy) {
		int priority = 0;

		if (enemy.isHumanAvatar()) {
			priority += 100;
		}

		priority += enemy.getAttack();
		priority += (enemy.getMaxHealth() - enemy.getHealth());

		return priority;
	}

	public boolean hasProvokeAbility(){
		return (this.getAbility1()!=null && this.getAbility1().contains("Provoke")) || (this.getAbility2()!=null && this.getAbility2().contains("Provoke"));
	}

	private static boolean isPathBlocked(Tile startTile, Tile endTile) {
		int startX = startTile.getTilex();
		int startY = startTile.getTiley();
		int endX = endTile.getTilex();
		int endY = endTile.getTiley();

		if (startY == endY) {
			for (int x = Math.min(startX, endX) + 1; x < Math.max(startX, endX); x++) {
				if (hasUnitAt(x, startY)) {
					return true;
				}
			}
		}

		if (startX == endX) {
			int minY = Math.min(startY, endY);
			int maxY = Math.max(startY, endY);
			for (int y = minY + 1; y < maxY; y++) {
				if (hasUnitAt(startX, y)) {
					return true;
				}
			}
		}

		return false;
	}

	private void move(ActorRef out, Unit unit, Tile startTile, Tile endTile, boolean yFirst) {
		startTile.setUnitToTile(null);
		endTile.setUnitToTile(unit);
		unit.setPositionByTile(endTile);
		moved = true;

		if (yFirst) {
			BasicCommands.moveUnitToTile(out, unit, endTile, true);
			try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
		} else {
			BasicCommands.moveUnitToTile(out, unit, endTile);
			try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
		}
	}

	private static boolean hasUnitAt(int x, int y) {
		if (x < 0 || x >= GameState.tileGrid.length || y < 0 || y >= GameState.tileGrid[0].length) {
			return false;
		}

		Tile tile = GameState.tileGrid[x][y];
		return tile.getUnitFromTile() != null;
	}

	public static Unit summonWraithling(ActorRef out, Tile wrathlingTile, GameState gameState) {
		return gameState.createUnit(out, wrathlingTile, StaticConfFiles.u_wraithling);
	}

	public boolean isStunned() {
		return stunnedTurns > 0;
	}

	public void setStunnedTurns(int turns) {
		this.stunnedTurns = turns;
	}

	public void reduceStunnedTurns() {
		if (stunnedTurns > 0) {
			stunnedTurns--;
		}
	}



	//* Automatically moves to the vicinity of the target unit (empty space around the endTile) before attacking

	public void moveAndAttack(ActorRef out, Tile startTile, Tile endTile, GameState gameState) {
		Unit attacker = startTile.getUnitFromTile();
		Unit target = endTile.getUnitFromTile();

		System.out.println("entered move and attack");
		if (attacker == null || target == null ){
			BasicCommands.addPlayer1Notification(out, "❌ Invalid action: Unit is null.", 2);
			return;
		}
		
		else if (attacker.isStunned()) {
			BasicCommands.addPlayer1Notification(out, "❌ Invalid action: Unit is Stunned.", 2);
			return;
		}
		
		else if (attacker.hasMoved() && attacker.hasAttacked()){
			BasicCommands.addPlayer1Notification(out, "❌ Invalid action: Unit already moved/attacked.", 2);
			return;
		}
		
		else if(gameState.hasUnitsummoned(attacker)) {
			BasicCommands.addPlayer1Notification(out, "❌ Invalid action: Unit cannot attack right in this turn.", 2);
			return;
		}

		if (isAdjacent(startTile, endTile)) {
			applyDamage(out, target, gameState);
			System.out.println("unit in adjacent block");
			gameState.clearHighlight(out);
			//try { Thread.sleep(1000); } catch (InterruptedException e) { e.printStackTrace(); }
			gameState.markUnitAsAttacked(attacker);
			if (target.getHealth() <= 0) {
				gameState.removeDeadUnit(out, target, endTile);
			} else {
				counterAttack(out, target, attacker, startTile, endTile, gameState);
			}
			return;
		}

		// Check if the target is within attack range
	
		int dx = Math.abs(startTile.getTilex() - endTile.getTilex());
		int dy = Math.abs(startTile.getTiley() - endTile.getTiley());

		if(((dx >=2 || dy >= 2) && (dx+dy <= 4)) && Math.max(dx, dy) <=3){
			List<Tile> emptyTiles = getEmptyTilesAround(gameState, endTile);
			if (emptyTiles.isEmpty()) {
				BasicCommands.addPlayer1Notification(out, "❌ No space near the enemy to move!", 2);
				return;
			}
			System.out.println("unit is move and attack - unit.java");

			Tile bestMoveTile = findBestMoveTileToAttack(gameState, startTile, emptyTiles);
			if (bestMoveTile == null) {
				System.out.println("bestmove tile null");
				BasicCommands.addPlayer1Notification(out, "❌ Cannot reach any empty space near the target!", 2);
				return;
			}

			gameState.clearHighlight(out);
			this.moveUnit(out, startTile, bestMoveTile, gameState);

			//try { Thread.sleep(2000); } catch (InterruptedException e) { e.printStackTrace(); }
			if (isAdjacent(this.getTileFromUnit(gameState), endTile)) {
				if(attacker.hasProvoke && !target.hasProvokeAbility()){
					BasicCommands.addPlayer1Notification(out, "❌ Unit has been provoked: Unit cannot move/attack.", 2);
					return;
				}
				attacker.martyr=true;
				applyDamage(out, target, gameState);
				gameState.markUnitAsAttacked(attacker);
				if (target.getHealth() <= 0) {
					gameState.removeDeadUnit(out, target, endTile);
				} else {
					counterAttack(out, target, attacker, bestMoveTile, endTile, gameState);
				}
			}
		}
	}

	private List<Tile> calculatePath(Tile start, Tile end, GameState gameState) {
		List<Tile> path = new ArrayList<>();
	
		int dx = Integer.signum(end.getTilex() - start.getTilex());
		int dy = Integer.signum(end.getTiley() - start.getTiley());
	
		int x = start.getTilex();
		int y = start.getTiley();
	
		while (x != end.getTilex() || y != end.getTiley()) {
			x += dx;
			y += dy;
	
			Tile tile = gameState.getTileByCoordinates(x, y);
			if (tile == null) return new ArrayList<>();
			path.add(tile);
		}
	
		return path;
	}
	
	public List<Tile> getEmptyTilesAround(GameState gameState, Tile endTile) {
		List<Tile> emptyTiles = new ArrayList<>();
		int[][] directions = {
			{-1, -1}, {0, -1}, {1, -1},  
			{-1, 0},           {1, 0},   
			{-1, 1},  {0, 1},  {1, 1}    
		};

		for (int[] dir : directions) {
			int newX = endTile.getTilex() + dir[0];
			int newY = endTile.getTiley() + dir[1];

			if (newX >= 0 && newX < 9 && newY >= 0 && newY < 5) {
				Tile adjacentTile = gameState.getTileByCoordinates(newX, newY);
				if (adjacentTile != null && adjacentTile.getUnitFromTile() == null) {
					emptyTiles.add(adjacentTile);
				}
			}
		}
		return emptyTiles;
	}

	//Getting all the neighbouring units
	public List<Unit> getNeighbourUnits(GameState gameState, Tile centerTile){
		List<Unit> neighbourUnits = new ArrayList<>();
		int[][] adjacents = {
				{-1, -1}, {0, -1}, {1, -1},  
				{-1, 0},           {1, 0},   
				{-1, 1},  {0, 1},  {1, 1} 	
		};
		
		for (int[] dir : adjacents) {
			int checkX = centerTile.getTilex() + dir[0];
			int checkY = centerTile.getTiley() + dir[1];		
		
			if (checkX >= 0 && checkX < 9 && checkY >= 0 && checkY < 5) {
				Tile adjacentTile = GameState.tileGrid[checkX][checkY];
				if (adjacentTile != null) {
					Unit unit = adjacentTile.getUnitFromTile();
					if (unit != null) {
						neighbourUnits.add(unit);
					}
				}
			}
			
		}
		return neighbourUnits;	
	}

	/**
	 * :: Selection of the best moving Tile
	 */
	public Tile findBestMoveTileToAttack(GameState gameState, Tile startTile, List<Tile> emptyTiles) {
		Tile bestTile = null;
		int shortestDistance = Integer.MAX_VALUE;

		for (Tile emptyTile : emptyTiles) {
			if (canMoveToEmptyTileAround(gameState, startTile, emptyTile)) {
				int distance = emptyTile.calculateDistance(startTile);

				if (distance < shortestDistance) {
					shortestDistance = distance;
					bestTile = emptyTile;
				}
			}
		}

		if (bestTile == null) {
			for (Tile emptyTile : emptyTiles) {
				int distance = emptyTile.calculateDistance(startTile);

				if (distance < shortestDistance) {
					shortestDistance = distance;
					bestTile = emptyTile;
				}
			}
		}

		return bestTile;
	}

	public boolean canMoveToEmptyTileAround(GameState gameState, Tile startTile, Tile adjacentTile) {
		if (adjacentTile == null || adjacentTile.getUnitFromTile() != null) {
			return false;
		}
		int distance = adjacentTile.calculateDistance(startTile);

		return distance == 1 || distance == 2 || distance == 3;
	}

	public static void deadWatchedAbilities(ActorRef out, Unit unit, GameState gameState) {
		for (int i = 0; i < GameState.COLS ; i++) {
			for (int j = 0; j <GameState.ROWS; j++ ) {
				Tile tileChecked = GameState.tileGrid[i][j];
				if (tileChecked != null) {
					Unit unitChecked = tileChecked.getUnitFromTile();
					if (unitChecked != null && unitChecked.getAbility1() != null && unitChecked.getAbility1().contains("Deathwatch")) {
						if (unitChecked.getUnitName().contains("Bad Omen")) {
							unitChecked.setAttack(unitChecked.getAttack() + 1);
							try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
							BasicCommands.setUnitAttack(out, unitChecked, unitChecked.getAttack());
							BasicCommands.addPlayer1Notification(out, "Bad Omen Deathwatch: Attack + 1", 2);
						} 
						if (unitChecked.getUnitName().contains("Shadow Watcher")) {
							unitChecked.setAttack(unitChecked.getAttack() + 1);
							unitChecked.setHealth(unitChecked.getHealth() + 1);
							try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
							BasicCommands.setUnitAttack(out, unitChecked, unitChecked.getAttack());
							BasicCommands.setUnitHealth(out, unitChecked, unitChecked.getHealth());
							BasicCommands.addPlayer1Notification(out, "Shadow Watcher Attack & Health + 1", 2);
						}  
						if (unitChecked.getUnitName().contains("Shadowdancer")) {
							GameState.aiAvatar.setHealth(GameState.aiAvatar.getHealth() - 1);
							unitChecked.setHealth(unitChecked.getHealth() + 1);
							BasicCommands.setUnitHealth(out, unitChecked, unitChecked.getHealth());
							BasicCommands.setUnitHealth(out, GameState.aiAvatar, GameState.aiAvatar.getHealth());
							BasicCommands.addPlayer1Notification(out, "Shadowdancer Health + 1, Enemy Avator Health - 1", 2);
							//Checks if Shadowdancer's Deathwatch has killed the AI avatar
							if (GameState.aiAvatar.getHealth() == 0) {
								gameState.removeDeadUnit(out, GameState.aiAvatar, GameState.aiAvatar.getTileFromUnit(gameState));
							}
						}
						if (unitChecked.getUnitName().contains("Bloodmoon Priestess")) {
							Tile unitTile = unitChecked.getTileFromUnit(gameState);
							List<Tile> adjTiles = unitTile.getAdjacentTiles(gameState);
							for(Tile tile : adjTiles){
								if(tile.getUnitFromTile() == null){
									Unit newWraithling = summonWraithling(out, tile, gameState);
									try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
									break;
								}
							}	
						} 
						
					}
				}
			}
		}
	}

	public void OpeningGambitAbility(ActorRef out, GameState gameState, Tile clickedTile) {
		if (clickedTile == null || clickedTile.getUnitFromTile() == null) {
			return;
		}
		Unit summonedUnit = clickedTile.getUnitFromTile();
		if (summonedUnit != null ) {
			if (summonedUnit.getUnitName().contains("Gloom Chaser") ) {
				Tile summonedUnitTile = summonedUnit.getTileFromUnit(gameState);
				if (summonedUnit.getTileFromUnit(gameState) == null) {
					return;
				}
				
				if (summonedUnitTile.getTilex() - 1 < 0) {
					return;
				}

				int newX = summonedUnitTile.getTilex() - 1;
				if (newX < 0 || newX >= GameState.tileGrid.length) {
					return;
				}

				Tile wraithlingTile = GameState.tileGrid[summonedUnitTile.getTilex() - 1][summonedUnitTile.getTiley()];
				if (wraithlingTile != null && wraithlingTile.getUnitFromTile() == null) {							
					summonWraithling(out, wraithlingTile, gameState);
					BasicCommands.addPlayer1Notification(out, "Opening Gambit: summon wraithling", 2);
					return;
				}					
			} 
			else if (summonedUnit.getUnitName().contains("Nightsorrow Assassin") ) {
				List<Unit> neighbourUnits = getNeighbourUnits(gameState, clickedTile);
				if (neighbourUnits.isEmpty()) {
					return;
				}				
				for(Unit unit : neighbourUnits){
					Tile tile = unit.getTileFromUnit(gameState);
					if (unit.getPlayer() == gameState.getAiPlayer() && unit.getHealth() < unit.getMaxHealth() && unit.getId() != 1) {
						unit.setHealth(0);
						BasicCommands.setUnitHealth(out, unit, 0);		
						gameState.removeDeadUnit(out, unit, tile);
						BasicCommands.addPlayer1Notification(out, "Assassinated " + unit.getUnitName(), 2);
						return;		
					}
				}
			} 	//Player ID 1 indicates this Unit belongs to the AI player
			else if (summonedUnit.getPlayer().getId() == 1 && summonedUnit.getUnitName().contains("Silverguard Squire")) {
				Tile aiAvatarTile = GameState.aiAvatar.getTileFromUnit(gameState);
				int avatarX = GameState.aiAvatar.getTileFromUnit(gameState).getTilex();
				int avatarY = GameState.aiAvatar.getTileFromUnit(gameState).getTiley();
				if(avatarX >=1 && avatarX <=7){
					Tile directLeft = GameState.tileGrid[avatarX -1][avatarY];
					Unit directLeftUnit = directLeft.getUnitFromTile();
					Tile directRight = GameState.tileGrid[avatarX +1][avatarY];
					Unit directRightUnit = directRight.getUnitFromTile();	
					if (directLeft != null && directLeftUnit != null && directLeftUnit.getPlayer() == gameState.getAiPlayer()) {
						int unitLeftNewAttack = directLeftUnit.getAttack() +1;
						int unitLeftNewHealth = directLeftUnit.getHealth() +1;
						directLeftUnit.setAttack(unitLeftNewAttack);
						directLeftUnit.setHealth(unitLeftNewHealth);
						try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
						BasicCommands.setUnitAttack(out, directLeftUnit, unitLeftNewAttack);
						BasicCommands.setUnitHealth(out, directLeftUnit, unitLeftNewHealth);
					}
					if ( directRightUnit != null && directRightUnit != null && directRightUnit.getPlayer() == gameState.getAiPlayer()) {
						int unitRightNewAttack = directRightUnit.getAttack() +1;
						int unitRightNewHealth = directRightUnit.getHealth() +1;
						directRightUnit.setAttack(unitRightNewAttack);
						directRightUnit.setHealth(unitRightNewHealth);
						try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
						BasicCommands.setUnitAttack(out, directRightUnit, unitRightNewAttack);
						BasicCommands.setUnitHealth(out, directRightUnit, unitRightNewHealth);	
					}
				}
			}
		}
	}
	
	public void handleProvoke(Tile tile, GameState gameState, boolean applyProvoke){
		int[][] directions = {
			{-1, -1}, {0, -1}, {1, -1},  
			{-1, 0},           {1, 0},   
			{-1, 1},  {0, 1},  {1, 1}    
		};

		for (int[] dir : directions) {
			int newX = tile.getTilex() + dir[0];
			int newY = tile.getTiley() + dir[1];

			if (gameState.isValidTile(newX, newY)) {
				Tile adjacentTile = GameState.tileGrid[newX][newY];
				Unit adjacentUnit = adjacentTile.getUnitFromTile();
				if (adjacentUnit != null && adjacentUnit.getPlayer() != this.getPlayer()) {
					adjacentUnit.hasProvoke = applyProvoke;
				}
			}
		}
	}
	public void applyProvokeAbility(Tile tile, GameState gameState) {
		if (this.hasProvokeAbility()) {
			handleProvoke(tile, gameState, true); // Apply Provoke
		}
	}
	
	public void removeProvokeAbility(Tile tile, GameState gameState) {
		if (this.hasProvokeAbility()) {
			handleProvoke(tile, gameState, false); // Remove Provoke
		}
	}

	// Check if the unit can move
	public boolean canMove(GameState gameState) {
		return !gameState.getGameOver() && !gameState.hasUnitsummoned(this) && !this.isStunned() && !this.hasProvoke && this.getPlayer() != gameState.getCurrentPlayer() && !gameState.hasUnitMoved(this);
	}

	// Check if the unit can attack
	public boolean canAttack(GameState gameState) {
		return !gameState.getGameOver() && !gameState.hasUnitsummoned(this) && !this.isStunned() && this.getPlayer() != gameState.getCurrentPlayer() && !gameState.hasUnitAttacked(this);
	}


	@Override
	public String toString() {
		if (isHumanAvatar()) {
			return "Human Avatar";
		} else if (isAiAvatar()) {
			return "AI Avatar";
		}
		return unitName;
	}

	// Getters and setters
	public int getAttack() { return attack; }
	public void setAttack(int attack) { this.attack = attack; }
	public int getHealth() { return health; }
	public void setHealth(int health) { this.health = health; }
	public int getId() { return id; }
	public void setId(int id) { this.id = id; }
	public UnitAnimationType getAnimation() { return animation; }
	public void setAnimation(UnitAnimationType animation) { this.animation = animation; }
	public ImageCorrection getCorrection() { return correction; }
	public void setCorrection(ImageCorrection correction) { this.correction = correction; }
	public UnitAnimationSet getAnimations() { return animations; }
	public void setAnimations(UnitAnimationSet animations) { this.animations = animations; }
	public boolean hasMoved() { return this.moved; }
	public void setMoved(boolean moved) { this.moved = moved; }
    public boolean hasAttacked() {return attacked;}
    public void setAttacked(boolean attacked) {this.attacked = attacked;}
	public Player getPlayer() { return player; }
	public void setPlayer(Player player) { this.player = player; player.addUnitsForPlayer(this); }
	public Position getPosition() { return position; }
	public void setPosition(Position position) { this.position = position; }
	@JsonIgnore
	public void setPositionByTile(Tile tile) { this.position = new Position(tile.getXpos(), tile.getYpos(), tile.getTilex(), tile.getTiley()); }
	public boolean isHumanAvatar() { return id == 0; }
	public boolean isAiAvatar() { return id == 1; }
	public int getMaxHealth() { return maxHealth; }
	public void setMaxHealth(int maxHealth) { this.maxHealth = maxHealth; }
	public int getRobustness() { return robustness; }
	public void setRobustness(int robustness) { this.robustness = robustness; }
	public String getAbility1() { return unitAbility1; }
	public void setAbility1(String ability) { this.unitAbility1 = ability; }
	public String getAbility2() { return unitAbility2; }
	public void setAbility2(String ability) { this.unitAbility2 = ability; }
	public String getUnitName() { 
		if (isHumanAvatar()) {
			return "Human Avatar";
		} else if (isAiAvatar()) {
			return "AI Avatar";
		}
		return unitName;
	}
	public void setUnitName(String unitName) { this.unitName = unitName; }
	public int getDeadWatched() { return this.deadWatched; }
	public void setDeadWatched(int deadWatched) { this.deadWatched = deadWatched; }
	public static int getGlobalDeadWatched() { return globalDeadWatched; }
	public static void setGlobalDeadWatched(int unitDeaths) { globalDeadWatched = unitDeaths; }
	public static void incrementGlobalDeadWatched() { globalDeadWatched++; }
	public boolean isMartyr(){ return this.martyr; }
}


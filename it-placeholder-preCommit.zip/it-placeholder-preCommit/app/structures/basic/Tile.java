package structures.basic;

import structures.GameState;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import structures.GameState;

/**
 * A basic representation of a tile on the game board. Tiles have both a pixel position
 * and a grid position. Tiles also have a width and height in pixels and a series of urls
 * that point to the different renderable textures that a tile might have.
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Tile {

	@JsonIgnore
	private static ObjectMapper mapper = new ObjectMapper(); // Jackson Java Object Serializer, is used to read java objects from a file
	
	List<String> tileTextures;
	int xpos;
	int ypos;
	int width;
	int height;
	int tilex;
	int tiley;
	Unit unit;

	
	public Tile() {
	}
	
	public Tile(String tileTexture, int xpos, int ypos, int width, int height, int tilex, int tiley) {
		super();
		tileTextures = new ArrayList<String>(1);
		tileTextures.add(tileTexture);
		this.xpos = xpos;
		this.ypos = ypos;
		this.width = width;
		this.height = height;
		this.tilex = tilex; // Shows column number
		this.tiley = tiley; // Shows row number
	}
	
	public Tile(List<String> tileTextures, int xpos, int ypos, int width, int height, int tilex, int tiley) {
		super();
		this.tileTextures = tileTextures;
		this.xpos = xpos;
		this.ypos = ypos;
		this.width = width;
		this.height = height;
		this.tilex = tilex;
		this.tiley = tiley;
	}
	public List<String> getTileTextures() {
		return tileTextures;
	}
	public void setTileTextures(List<String> tileTextures) {
		this.tileTextures = tileTextures;
	}
	public int getXpos() {
		return xpos;
	}
	public void setXpos(int xpos) {
		this.xpos = xpos;
	}
	public int getYpos() {
		return ypos;
	}
	public void setYpos(int ypos) {
		this.ypos = ypos;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getTilex() {
		return tilex;
	}
	public void setTilex(int tilex) {
		this.tilex = tilex;
	}
	public int getTiley() {
		return tiley;
	}
	public void setTiley(int tiley) {
		this.tiley = tiley;
	}
	
	/**
	 * Loads a tile from a configuration file
	 * parameters.
	 * @param configFile
	 * @return
	 */
	public static Tile constructTile(String configFile) {
		
		try {
			Tile tile = mapper.readValue(new File(configFile), Tile.class);
			return tile;
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return null;
		
	}
	  //unit-->tile 
	// Sets the unit on the tile
	public void setUnitToTile(Unit unit) {
		if (unit == null) {
			this.unit = null;
		} else {
			this.unit = unit;
			unit.setPositionByTile(this);  // 确保 unit 不为 null
		}
	}
	
	//tile<--unit
	// Returns the unit on the tile 
	public Unit getUnitFromTile() {
		return unit;
	}

	public boolean isOccupied() {
		return getUnitFromTile() != null;
	}

	public int calculateDistance(Tile t) {
		return Math.abs(this.getTilex() - t.getTilex()) + Math.abs(this.getTiley() - t.getTiley());
	}

	// This method checks if a tile is valid to place a unit
	// Returns true if the tile is not ocupied and adjacent to a friendly unit
	// Tile column: x, Tile row: y (this is how the board was built)
	public boolean isValidToPlaceUnit(GameState gameState) {
		if (this.isOccupied()) return false;
		
		int[][] directions = {
			{ 0, -1 },	// Up (row - 1)
			{ 0, 1 },	// Down (row + 1)
			{ 1, 0 },	// Right (col + 1)
			{ -1, 0 },	// Left (col - 1)
			{ 1, -1 },	// Diagonal Up-Right (col + 1, row - 1)
			{ 1, 1 }, 	// Diagonal Down-Right (col + 1, row + 1)
			{ -1, -1 }, // Diagonal Up-Left (col - 1, row - 1)
			{ -1, 1 } 	// Diagonal Down-Left (col - 1, row + 1)
		};

		for (int[] dir : directions) {
			int newX = tilex + dir[0];
			int newY = tiley + dir[1];
			
			if (gameState.isValidTile(newX, newY)) {
				Tile adjacentTile = GameState.tileGrid[newX][newY];
				if (adjacentTile.isOccupied() && adjacentTile.getUnitFromTile().getPlayer() == gameState.getCurrentPlayer()) {
					return true;
				}
			}
		}
		return false;
	}

	// Returns a list of adjacent tiles (8 directions) excluding out-of-bound tiles
	public List<Tile> getAdjacentTiles(GameState gameState) {
		List<Tile> adjacentTiles = new ArrayList<>();

		int[][] directions = {
			{ 0, -1 },	// Up (row - 1)
			{ 0, 1 },	// Down (row + 1)
			{ 1, 0 },	// Right (col + 1)
			{ -1, 0 },	// Left (col - 1)
			{ 1, -1 },	// Diagonal Up-Right (col + 1, row - 1)
			{ 1, 1 }, 	// Diagonal Down-Right (col + 1, row + 1)
			{ -1, -1 }, // Diagonal Up-Left (col - 1, row - 1)
			{ -1, 1 } 	// Diagonal Down-Left (col - 1, row + 1)
		};

		for (int[] dir : directions) {
			int newX = this.tilex + dir[0];
			int newY = this.tiley + dir[1];
			
			if (gameState.isValidTile(newX, newY)) {
				Tile adjacentTile = GameState.tileGrid[newX][newY];
				adjacentTiles.add(adjacentTile);
			}
		}

		return adjacentTiles;
	}

	// Returns a list of unocuppied adjacent tiles
	public List<Tile> getUnocuppiedAdjacentTiles(GameState gameState) {
		List<Tile> tiles = new ArrayList<>();

		for (Tile tile : getAdjacentTiles(gameState)) {
			if (!tile.isOccupied()) {
				tiles.add(tile);
			}

		}

		return tiles;
	}


	// Returns true if this tile is adjacent to an enemy unit of the current player
	public boolean isAdjacentToEnemy(GameState gameState) {
		List<Tile> adjacentTiles = getAdjacentTiles(gameState);
		for (Tile tile : adjacentTiles) {
			Unit unit = tile.getUnitFromTile();
			if (unit != null && unit.getPlayer() != gameState.getCurrentPlayer()) {
				return true;
			}
		}
		return false;
	}


}

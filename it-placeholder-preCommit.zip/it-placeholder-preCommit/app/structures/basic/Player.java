package structures.basic;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A basic representation of of the Player. A player
 * has health and mana.
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Player {
	private int health;
	private int mana;
	private int id;
	private Unit avatar;
	private List<Card> cardDeck;	// All cards that player can draw from
	private List<Card> cardsOnHand;	// Current cards held by player
	private List<Unit> units = new ArrayList<>();
	
	public Player() {
		this.health = 20;
		this.mana = 0;
		this.cardDeck = new ArrayList<>(20);
		this.cardsOnHand = new ArrayList<>(6);
	}

	public Player(int health, int mana, int id) {
		this.health = health;
		this.mana = mana;
		this.id = id;
		this.cardDeck = new ArrayList<>(20);
		this.cardsOnHand = new ArrayList<>(6);
	}

	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		this.health = health;
	}
	public int getMana() {
		return mana;
	}
	public void setMana(int mana) {
		this.mana = mana;
	}
	
	public Unit getAvatar() {
		return avatar;
	}
	public void setAvatar(Unit avatar) {
		this.avatar = avatar;
	}
	public void addUnitsForPlayer(Unit unit) {
		this.units.add(unit);
	}

	public List<Unit> getAllUnits(){
		return units;
	}

	public List<Unit> getAiUnits(GameState gameState) {
		List<Unit> aiUnitsList = new ArrayList<>();
		for (Unit unit : units) {
			if (unit.getPlayer() != null && unit.getPlayer().isAI(gameState)) {  
				aiUnitsList.add(unit);
			}
		}
		// System.out.println("Obtain AI units, quantity." + aiUnitsList.size());
		return aiUnitsList;
	}

	public void removeUnit(GameState gameState, Unit unit){
		if(!units.isEmpty()){
			units.remove(unit);
		}
	}
	
	public List<Unit> getHumanUnits(GameState gameState) {
		List<Unit> humanUnitsList = new ArrayList<>();
		for (Unit unit : units) {
			if (unit.getPlayer() != null && !unit.getPlayer().isAI(gameState)) {  
				humanUnitsList.add(unit);
			}
		}
		// System.out.println("Get Human Units, Quantity. " + humanUnitsList.size());
		return humanUnitsList;
	}
	


	public boolean isAI(GameState gameState) {
    return this == gameState.getAiPlayer(); //  
}


	public int getId(){
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public List<Card> getCardDeck() {
		return cardDeck;
	}

	public List<Card> getCardsOnHand() {
		return cardsOnHand;
	}

	public void setCardDeck(List<Card> cardDeck) {
		this.cardDeck = cardDeck;
	}

	public void setCardsOnHand(List<Card> cardsOnHand) {
		this.cardsOnHand = cardsOnHand;
	}	

	public void drawCard(ActorRef out, int numOfCards) {
		for (int time = 0; time < numOfCards; time++) {
			if (isCardDeckEmpty()) {
				BasicCommands.addPlayer1Notification(out, "Card deck is empty.", 2);
				return;
			}

			if (isHandFull()) {
				BasicCommands.addPlayer1Notification(out, "Hand is full.", 2);
				return;
			}

			int randomIndex = (new Random()).nextInt(cardDeck.size());
			Card drawnCard = cardDeck.get(randomIndex);
			cardDeck.remove(drawnCard);
			cardsOnHand.add(drawnCard);
		}
	}

	// Helper method for drawCard
	private boolean isCardDeckEmpty() {
		return cardDeck.isEmpty();
	} 

	// Helper method for drawCard
	private boolean isHandFull() {
		return cardsOnHand.size() == 6;
	}

	public void updateAndDisplayHealth(ActorRef out, int newHealth) {
		setHealth(newHealth);
		// If human player
		if (id == 0) {
			BasicCommands.setPlayer1Health(out, this);
		// If AI player
		} else if (id == 1) {
			BasicCommands.setPlayer2Health(out, this);
		}
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
	}
}

package structures.basic;

import commands.BasicCommands;
import akka.actor.ActorRef;
import structures.GameState;
import structures.basic.Unit;


/**
 * This is the base representation of a Card which is rendered in the player's hand.
 * A card has an id, a name (cardname) and a manacost. A card then has a large and mini
 * version. The mini version is what is rendered at the bottom of the screen. The big
 * version is what is rendered when the player clicks on a card in their hand.
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Card {
	int id;
	String cardname;
	int manacost;
	
	MiniCard miniCard;
	BigCard bigCard;
	
	boolean isCreature;
	String unitConfig;
	
	public Card() {};
	
	public Card(int id, String cardname, int manacost, MiniCard miniCard, BigCard bigCard, boolean isCreature, String unitConfig) {
		super();
		this.id = id;
		this.cardname = cardname;
		this.manacost = manacost;
		this.miniCard = miniCard;
		this.bigCard = bigCard;
		this.isCreature = isCreature;
		this.unitConfig = unitConfig;
	}

	public boolean applySpell(ActorRef out, GameState gameState, Unit unit){
		Player currentPlayer = gameState.getCurrentPlayer();
		boolean isSpellApplied = false;

		if(gameState.getCurrentPlayer().getMana() < this.manacost){
			BasicCommands.addPlayer1Notification(out,"Not enough mana to apply the spell", 2);
			gameState.clearHighlight(out);
			return false;
		}

		if(currentPlayer.isAI(gameState) && currentPlayer.getCardsOnHand().size() == 1 && currentPlayer.getCardDeck().isEmpty())
			return false;

		switch (cardname) {
            case "Sundrop Elixir":
				isSpellApplied = applySundropElixir(out, gameState, unit);
                break;
            case "Truestrike":
                isSpellApplied = applyTruestrike(out, gameState, unit);
                break;
            case "Beamshock":
                isSpellApplied = applyBeamshock(out, gameState, unit);
                break;
            case "Dark Terminus":
                isSpellApplied = applyDarkTerminus(out, gameState, unit);
                break;
			case "Horn of the Forsaken":
				isSpellApplied = applyHornOfTheForsaken(out, gameState, unit);
				break;
			case "Wraithling Swarm":
				isSpellApplied = applyWraithlingSwarm(out, gameState, gameState.getClickedTile());
				break;
			
            default:
                BasicCommands.addPlayer1Notification(out, "Invalid Card detected.", 2);
                break;
        }

		// If spell is applied, reduce the player's mana and remove the used spell from cardsOnHand
		if(isSpellApplied){
			currentPlayer.setMana(currentPlayer.getMana() - manacost);
            if (currentPlayer.getId() == GameState.HUMAN_PLAYER_ID) {
                BasicCommands.setPlayer1Mana(out, currentPlayer);
            } else {
                BasicCommands.setPlayer2Mana(out, currentPlayer);
			}
			currentPlayer.getCardsOnHand().remove(this);
			
			if(currentPlayer == gameState.getHumanPlayer()) {
				gameState.displayPlayersCard(out, gameState.getHumanPlayer());
			}
			
			return true;
		}
		return false;
	}

	// AICommands class has passed an AI unit with health <= maxHealth - 5 when calling this method
	public boolean applySundropElixir(ActorRef out, GameState gameState, Unit unit){
		// TODO priority: avatar > attack max > attack order 
		
		int currHealth = unit.getHealth();
		int maxHealth = unit.getMaxHealth();
		int healthDifference = maxHealth - currHealth;
		//If condition to check stop unit being applied to enemy
		if (unit.getPlayer().getId() == 1) {
			//Want to apply all the benefits if there is sufficient difference
			if (currHealth < maxHealth && healthDifference > 5) {
				unit.setHealth(currHealth + 5); 
			//Else if: apply what difference we can to the unit's health
			} else if ( (currHealth < maxHealth) && (healthDifference <= 5) && (healthDifference > 0) ) {
				unit.setHealth(currHealth + healthDifference);
			//Else if: don't apply when current health = max health & exit method
			} else if (currHealth >= maxHealth) {
				return false;
			} 			
			BasicCommands.setUnitHealth(out, unit, unit.getHealth()); 
			BasicCommands.playEffectAnimation(out, EffectAnimation.buff(), unit.getTileFromUnit(gameState));
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
			// Update AI player's health if unit is avatar
			if(unit.isAiAvatar()){
				gameState.getAiPlayer().updateAndDisplayHealth(out, unit.getHealth());
			}
		return true;
		//Otherwise don't apply spell to enemy unit
		} else {		
		return false;
		}
		
	}
	
	public boolean applyTruestrike(ActorRef out, GameState gameState, Unit unit) {
        if (unit != null && unit.getPlayer() != gameState.getCurrentPlayer()) {
            Player currentPlayer = gameState.getCurrentPlayer();
            if (currentPlayer.getMana() >= manacost) {
                Unit caster = gameState.getCurrentPlayer().getAvatar();
                if (caster != null) {
                    try {Thread.sleep(BasicCommands.playUnitAnimation(out, caster, UnitAnimationType.attack));} catch (InterruptedException e) {e.printStackTrace();}
                }

                try {Thread.sleep(BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.hit));} catch (InterruptedException e) {e.printStackTrace();}

                int newHealth = Math.max(0, unit.getHealth() - 2);
                unit.setHealth(newHealth);
                BasicCommands.setUnitHealth(out, unit, newHealth);

                if (newHealth == 0) {
					gameState.removeDeadUnit(out, unit, unit.getTileFromUnit(gameState));
                } else {
                    try {Thread.sleep(BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.idle));} catch (InterruptedException e) {e.printStackTrace();}
                }
				if(unit.isHumanAvatar()){
					unit.getPlayer().updateAndDisplayHealth(out,newHealth);
				}
				return true;
            }
        } else {
            BasicCommands.addPlayer1Notification(out, "❌ Select an enemy unit to cast Truestrike!", 2);
        }

		return false;
    }


	// This is only called after AICommands already checked valid mana cost and unit not null. When called, directly stuns target unit
    public boolean applyBeamshock(ActorRef out, GameState gameState, Unit unit) {
		unit.setStunnedTurns(2);
		gameState.addStunnedUnit(unit);
		System.out.println("Unit " + unit.getUnitName() + " is stunned");
		gameState.clearHighlight(out);

		Unit aiAvatar = gameState.getAiAvatar();
		
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, aiAvatar, UnitAnimationType.attack));} catch (InterruptedException e) {e.printStackTrace();}
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.hit));} catch (InterruptedException e) {e.printStackTrace();}
		try {Thread.sleep(BasicCommands.playUnitAnimation(out, aiAvatar, UnitAnimationType.idle));} catch (InterruptedException e) {e.printStackTrace();}
		
		return true;
}

    public boolean applyDarkTerminus(ActorRef out, GameState gameState, Unit unit) {
		gameState.clearHighlight(out);
		boolean isSpellApplied = false;
        if (unit != null && unit.getPlayer() != gameState.getCurrentPlayer()) {
            if (!unit.isAiAvatar()) {
                Player currentPlayer = gameState.getCurrentPlayer();
                BasicCommands.addPlayer1Notification(out, "Success: unit on tile destroyed.", 2);
				unit.setHealth(0);
				BasicCommands.setUnitHealth(out, unit, 0);   
				try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
                gameState.removeDeadUnit(out, unit, unit.getTileFromUnit(gameState));
				isSpellApplied = true;
				gameState.summonWraithling(out, unit.getTileFromUnit(gameState));
            } else {
                BasicCommands.addPlayer1Notification(out, "Invalid: can't cast on enemy Avatar.", 2);
            }
        } else if (unit == null) {
            BasicCommands.addPlayer1Notification(out, "Invalid: no unit on tile.", 2);
        }
		return isSpellApplied;
    }


	// When casted on human avatar, human avatar is equipped with artifact with 3 robustness
	// Whenever avatar takes damage, decrease 1 robustness. Artifact is destroyed when robustness reaches 0
	// On hit: whenever hits an enemy, summon a Wraithing on a random unoccupied adjacent tile.
	public boolean applyHornOfTheForsaken(ActorRef out, GameState gameState, Unit unit) {
		gameState.clearHighlight(out);
		if (unit != gameState.getHumanAvatar()) {
			BasicCommands.addPlayer1Notification(out, "Must be casted on Human avatar.", 2);
			return false;
		} else {
			BasicCommands.addPlayer1Notification(out, "Spell casted on Human avatar.", 2);
			BasicCommands.playEffectAnimation(out, EffectAnimation.buff(), unit.getTileFromUnit(gameState));
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
			unit.setRobustness(3);
			return true;
		}
	}


	// Allows player to summon 3 wraithings to 3 selected tiles
	public boolean applyWraithlingSwarm(ActorRef out, GameState gameState, Tile clickedTile) {
		// If there are not 3 available free tiles on board, return false
		int freeTiles = 0;
		for (Tile[] row : GameState.tileGrid) {
			for (Tile tile : row) {
				if (!tile.isOccupied()) {
					freeTiles += 1;
				}
			}
		}
		if (freeTiles < 3) {
			return false;
		}

		// If clicked tile is occupied, return false
		if (clickedTile.isOccupied()) {
			BasicCommands.addPlayer1Notification(out, "Must be placed on available tile.", 2);
			return false;
		}
		
		// Set the game to track Wraithling Swarm spell and place first wraithling on clickedTile
		gameState.setIsTrackingWraithlingSwarm(true);
		gameState.summonWraithling(out, clickedTile); // Place first wraithling
		gameState.setRemainingWraithlings(2);
		
		return true;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCardname() {
		return cardname;
	}
	public void setCardname(String cardname) {
		this.cardname = cardname;
	}
	public int getManacost() {
		return manacost;
	}
	public void setManacost(int manacost) {
		this.manacost = manacost;
	}
	public MiniCard getMiniCard() {
		return miniCard;
	}
	public void setMiniCard(MiniCard miniCard) {
		this.miniCard = miniCard;
	}
	public BigCard getBigCard() {
		return bigCard;
	}
	public void setBigCard(BigCard bigCard) {
		this.bigCard = bigCard;
	}

	public void setIsCreature(boolean isCreature) {
		this.isCreature = isCreature;
	}
	public void setCreature(boolean isCreature) {
		this.isCreature = isCreature;
	}
	public boolean isCreature() {
		return isCreature;
	}
	public String getUnitConfig() {
		return unitConfig;
	}
	public void setUnitConfig(String unitConfig) {
		this.unitConfig = unitConfig;
	}

	
}

package structures.basic;

public @interface JsonIgnore {

}

package structures;

import akka.actor.ActorRef;
import commands.AICommands;
import commands.BasicCommands;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import demo.TestCommands;
import structures.basic.*;
import utils.BasicObjectBuilders;
import utils.OrderedCardLoader;
import utils.StaticConfFiles;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

import java.util.stream.Stream;

import actors.GameActor;
import structures.basic.EffectAnimation;

/**
 * This class can be used to hold information about the on-going game.
 * Its created with the GameActor.
 * 
 * @author Dr. Richard McCreadie
 *
 */

public class GameState {
	public final static int ROWS = 5, COLS = 9;
    public static Tile tileGrid [][] = new Tile[COLS][ROWS]; // TODO: change to private
	public static final int HUMAN_PLAYER_ID = 0;
    public static final int AI_PLAYER_ID = 1;
    private Player humanPlayer, aiPlayer, currentPlayer;
	private Unit humanAvatar;
	public static Unit aiAvatar; 
    public static boolean gameInitialized = false;  
	public static boolean gameOver = false;		 
    public static boolean isPlayer1Turn = true;      // TODO: check if can remove
	private int humanTurnCounter = 0;
    private int aiTurnCounter = 0;
	private Set<Unit> movedUnits = new HashSet<>();
	private Set<Unit> attackedUnits = new HashSet<>();
	private Tile clickedTile;
	private Card selectedCard;
	private int nextUnitId = 0;
	private Set<Tile> highlightedTiles = new HashSet<>(); // Store removable grids 
    private Set<Tile> attackTiles = new HashSet<>(); // Store removable grids
	private Set<Unit> stunnedUnits = new HashSet<>();    //about the spell Beamshock
	private Map<String, String[]> UNIT_STATS = new HashMap<>();
    private AICommands aiCommands ;
	private boolean isTrackingWraithlingSwarm = false; // Tracks wraithling swarm spell until finishing placing 3 wraithlings
	private int remainingWraithlings; // Tracks wraithling swarm spell until finishing placing 3 wraithlings
	private final int MAX_MANA = 9;
    private GameActor gameActor;
	private Set<Unit> notMoveAndAttack = new HashSet<>();
	public GameState(GameActor gameActor) {
		this.gameActor = gameActor; // Store GameActor
		this.aiCommands = new AICommands(gameActor, this); // Pass GameActor and GameState
	}
	public boolean hasUnitsummoned(Unit unit) {           //qirui
		return notMoveAndAttack.contains(unit);
	}
	public void resetUnitsummoned()
	{
		notMoveAndAttack.clear();
	}
	public void loadUnitStats() {
        Path basePath = Paths.get("conf/gameconfs/cards");
        try (Stream<Path> paths = Files.walk(basePath)) {
            paths.filter(Files::isRegularFile)
                 .filter(path -> path.toString().endsWith(".json"))
                 .forEach(path -> {
                     try {
                         String content = new String(Files.readAllBytes(path));
                         ObjectMapper mapper = new ObjectMapper();
                         JsonNode cardNode = mapper.readTree(content);
                         if (cardNode.get("isCreature").asBoolean()) {
                             String unitConfig = cardNode.get("unitConfig").asText();
                             String attack = cardNode.get("bigCard").get("attack").asText();
                             String health = cardNode.get("bigCard").get("health").asText();
                             String unitName = cardNode.get("cardname").asText();
                             JsonNode rulesTextRows = cardNode.get("bigCard").get("rulesTextRows");
                             String ability1 = rulesTextRows.size() > 0 ? rulesTextRows.get(0).asText() : "";
                             String ability2 = rulesTextRows.size() > 1 ? rulesTextRows.get(1).asText() : "";
                             System.out.println(unitConfig + " and ability 2: " + ability2 + "\n");
                             UNIT_STATS.put(unitConfig, new String []{attack, health, ability1, ability2, unitName});                            
                         }
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
                 });
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*
		UNIT_STATS.put(StaticConfFiles.humanAvatar, new int[]{2, 20});
		UNIT_STATS.put(StaticConfFiles.aiAvatar, new int[]{2, 20});
		*/

		// Manually add stats for avatars and wraithing
    	UNIT_STATS.put(StaticConfFiles.wraithling, new String[]{"1", "1", "", "", "Wraithling"});
     
    }

		
	public void drawGrid(ActorRef out){
		for (int i = 0; i < COLS; i++) {
            for (int j = 0; j < ROWS; j++) {                                                   
                //Tile tile = BasicObjectBuilders.loadTile(i, j);
                tileGrid [i][j] = BasicObjectBuilders.loadTile(i, j); 
                BasicCommands.drawTile(out, tileGrid[i][j], 0);
            }
        }
	}

	// This method creates a new unit and places it onto a chosen tile 
	public Unit createUnit(ActorRef out, Tile startTile, String configFile) {
		Unit newUnit = BasicObjectBuilders.loadUnit(configFile, nextUnitId++, Unit.class);
		
		// Set attack and health stats
        if (UNIT_STATS.containsKey(configFile)) {
            String[] stats = UNIT_STATS.get(configFile);
            newUnit.setAttack(Integer.parseInt(stats[0]));
            newUnit.setHealth(Integer.parseInt(stats[1]));
			newUnit.setAbility1( stats[2] );
			newUnit.setAbility2( stats[3] );
			newUnit.setUnitName( stats[4] );
        }
		newUnit.setMaxHealth(newUnit.getHealth());

		// Set position
		newUnit.setPositionByTile(startTile);
		startTile.setUnitToTile(newUnit);

		// Display unit, attack and health on game board
		BasicCommands.drawUnit(out, newUnit, startTile);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}

		// Play summon effect instead of channel animation and Set Players
		if(newUnit.getUnitName().equals("Wraithling")){
			BasicCommands.playEffectAnimation(out, EffectAnimation.wraithlingSummon(), startTile);
			newUnit.setPlayer(humanPlayer);
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
		} else {
			BasicCommands.playEffectAnimation(out, EffectAnimation.summon(), startTile);
			newUnit.setPlayer(currentPlayer);
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
		}
		

		BasicCommands.setUnitAttack(out, newUnit, newUnit.getAttack());
		try {Thread.sleep(200);} catch (InterruptedException e) {e.printStackTrace();}
        BasicCommands.setUnitHealth(out, newUnit, newUnit.getHealth());
		try {Thread.sleep(200);} catch (InterruptedException e) {e.printStackTrace();}

		return newUnit;
	}

	public Unit createAvatar(ActorRef out, Player player, String avatarConfig, int startX, int startY) {
		Tile startTile = tileGrid[startX][startY];
		Unit avatar = createUnit(out, startTile, avatarConfig);
		player.setAvatar(avatar);

		return avatar;
	}

	public void initialiseHumanPlayer(ActorRef out, int health, int mana) {
		Player humanPlayer = new Player(health, mana, HUMAN_PLAYER_ID);
		currentPlayer = humanPlayer;

		// Create human avatar
		Unit humanAvatar = createAvatar(out, currentPlayer, StaticConfFiles.humanAvatar, 1, 2);
        setHumanAvatar(humanAvatar);
	
		BasicCommands.setPlayer1Health(out, currentPlayer);
	
		// Load 20 cards into player's card deck
		List<Card> cardDeck = OrderedCardLoader.getPlayer1Cards(2);
		currentPlayer.setCardDeck(cardDeck);
	
		// Draw 3 cards
		currentPlayer.drawCard(out, 3);
		try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
		
		this.setHumanPlayer(currentPlayer);
	}

	public void initialiseAiPlayer(ActorRef out, int health, int mana) {
		Player aiPlayer = new Player(health, mana, AI_PLAYER_ID);
		currentPlayer = aiPlayer;

		// Create AI avatar
		Unit aiAvatar = createAvatar(out, currentPlayer, StaticConfFiles.aiAvatar, 7, 2);
        setAiAvatar(aiAvatar);

		BasicCommands.setPlayer2Health(out, currentPlayer);
	
		// Load 20 cards into player's card deck
		List<Card> cardDeck = OrderedCardLoader.getPlayer2Cards(2);
		currentPlayer.setCardDeck(cardDeck);

		// Draw 3 cards
		currentPlayer.drawCard(out, 3);
		try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
		
		this.setAiPlayer(currentPlayer);
	}
	
	public void startHumanTurn(ActorRef out) {
		currentPlayer = humanPlayer;
        humanTurnCounter++;
        int mana = humanTurnCounter + 1;
		if(mana > MAX_MANA) {
			mana = MAX_MANA;
		}
        humanPlayer.setMana(mana);
		BasicCommands.setPlayer1Mana(out, humanPlayer);
		setplayer1Turn(true);
		displayPlayersCard(out, humanPlayer);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
    }

	public void startAiTurn(ActorRef out) {
		currentPlayer = aiPlayer;
        aiTurnCounter++;
        int mana = aiTurnCounter + 1;
		if(mana > MAX_MANA) {
			mana = MAX_MANA;
		}
        aiPlayer.setMana(mana);
		BasicCommands.setPlayer2Mana(out, aiPlayer);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        aiCommands.executeAiTurn(out,this);     
    }

	/*
	 * For readability purpose, this method is created to display player's cardsOnHand
	 * when they are displayed for the first time in the game.
	 */
	public void displayPlayersCard(ActorRef out, Player player) {
		redrawPlayerHand(out, player);
	}

	public void redrawPlayerHand(ActorRef out, Player player) {
	    // Clear the hand
	    for (int i = 1; i <= 6; i++) {
	        BasicCommands.deleteCard(out, i);
	        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
	    }

	    // Not highlighted
	    int handPosition = 1;
	    for (Card card : player.getCardsOnHand()) {
	        if (card != null) {
	            BasicCommands.drawCard(out, card, handPosition, 0);
	            try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
	        }
	        handPosition++;
	    }
	    
	    // Highlighted
	    handPosition = 1;
	    for (Card card : player.getCardsOnHand()) {
	        if (card != null) {
	            BasicCommands.drawCard(out, card, handPosition, 1);
	            try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
	        }
	        handPosition++;
	    }
	}

	public boolean hasUnitMoved(Unit unit) {           //qirui    check if the unit have already moved
		return movedUnits.contains(unit);
	}
	public boolean hasUnitAttacked(Unit unit) {           //qirui    check if the unit have already moved
		return attackedUnits.contains(unit);
	}
	
	public void markUnitAsMoved(Unit unit) {             //qirui     mark the unit as moved
		movedUnits.add(unit);
	}
	public void markUnitAsAttacked(Unit unit) {attackedUnits.add(unit);}
	public void reset() {                      //qirui    reset the marks of units which is uesd to show they have moved
		movedUnits.clear();
	}
	public void AttackReset(){attackedUnits.clear(); }
  	
	/*
	 * Check for Win Condition, declare winner
	 * Acceptance test includes player's avatar removed from board, but this is handled within AvatarLeaveTile.removeDeadUnit
	 */
  	public void checkForWin(ActorRef out, Unit Avatar) {
  			String ggMessage;
  			if (Avatar.isHumanAvatar()){
  				ggMessage = "Player 2 wins!";
  				gameOver = true;
  				BasicCommands.addPlayer1Notification(out, ggMessage, 10);
  				
  			} else if (Avatar.isAiAvatar()){
  				ggMessage = "Player 1 wins!";
  				gameOver = true;
  				BasicCommands.addPlayer1Notification(out, ggMessage, 10);
  			} else {
  				
  				ggMessage = "Avatar still alive.";
  				BasicCommands.addPlayer1Notification(out, ggMessage, 2);
  			}
  		//Prints out ggMessage - needs to connected to Front-end box in game
  		System.out.println(ggMessage);	
  	}
    
  	
	public Tile getTileByCoordinates(int x, int y) {
        if (x < 0 || x >= tileGrid.length || y < 0 || y >= tileGrid[0].length) {
            return null;
        }
        return tileGrid[x][y];
    }

    //Getters and Setters for Class' attributes
  	public void setGameInitialised(boolean isGameInitialised) {gameInitialized = isGameInitialised;}
  	
  	public void setGameOver(boolean isGameOver) {gameOver = isGameOver;}
  	
  	public void setplayer1Turn(boolean isPlayerTurn) {isPlayer1Turn = isPlayerTurn;}
  	
  	public boolean getGameInitialised() {return gameInitialized;}
  	
  	public boolean getGameOver() {return gameOver;}
  	
  	public boolean getPlayer1Turn() {return isPlayer1Turn;}

	// Getters for turn counters
    public int getHumanTurnCounter() {
        return humanTurnCounter;
    }

    public int getAITurnCounter() {
        return aiTurnCounter;
    }

    //Setters to increment turn count after end turn clicked
    public void setHumanTurnCount(int number) {this.humanTurnCounter = this.humanTurnCounter + number;}
    
    public void setAITurnCount(int number) {this.aiTurnCounter = this.aiTurnCounter + number;}
   
	public Tile getClickedTile() {
		return clickedTile;
	}

	public void setClickedTile(Tile clickedTile) {
		this.clickedTile = clickedTile;
	}

	public Card getSelectedCard() {
		return selectedCard;
	}

	public void setSelectedCard(Card clickedCard) {
		this.selectedCard = clickedCard;
	}

	public boolean isValidTile(int x, int y) {
        return x >= 0 && x < COLS && y >= 0 && y < ROWS;
    }

	public int generateUniqueUnitId() {
	    return nextUnitId++;
	}

	public Player getHumanPlayer() {
		return humanPlayer;
	}

	public void setHumanPlayer(Player humanPlayer) {
		this.humanPlayer = humanPlayer;
	}

	public Player getAiPlayer() {
		return aiPlayer;
	}

	public void setAiPlayer(Player aiPlayer) {
		this.aiPlayer = aiPlayer;
	}

	public Player getCurrentPlayer() {
		return currentPlayer;
	}

	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}


	public void addHighlightedTile(Tile tile) {
		highlightedTiles.add(tile);
	}
	
	public void addAttackTile(Tile tile) {
		attackTiles.add(tile);
	}
	public Set<Tile> getHighlightedTiles() {
		return highlightedTiles;
	}
	
	public Set<Tile> getAttackTiles() {
		return attackTiles;
	}

	public Map<String, String[]> getUnitStats() {
		return UNIT_STATS;
	}
	
	public Unit getHumanAvatar() {
		return humanAvatar;
	}

	public Unit getAiAvatar() {
		return aiAvatar;
	}

	public void setHumanAvatar(Unit humanAvatar) {
		this.humanAvatar = humanAvatar;
	}

	public void setAiAvatar(Unit aiAvatar) {
		this.aiAvatar = aiAvatar;
	}

	public boolean isTrackingWraithlingSwarm() {
		return isTrackingWraithlingSwarm; 
	}

	public void setIsTrackingWraithlingSwarm(boolean isTrackingWraithlingSwarm) {
		this.isTrackingWraithlingSwarm = isTrackingWraithlingSwarm;
	}

	public int getRemainingWraithlings() {
		return remainingWraithlings;
	}

	public void setRemainingWraithlings(int remainingWraithlings) {
		this.remainingWraithlings = remainingWraithlings;
	}

	public void reduceRemainingWraithlings() {
		if (remainingWraithlings > 0) {
			remainingWraithlings -= 1;
		}
	}

	public Set<Unit> getNotMoveAndAttackSet() {
		return notMoveAndAttack;
	}

	public void clearHighlight(ActorRef out) {
		if (!highlightedTiles.isEmpty() || !attackTiles.isEmpty()) {
			for (Tile tile : highlightedTiles) {
				BasicCommands.drawTile(out, tile, 0); // 
			}
			for (Tile tile : attackTiles) {
				BasicCommands.drawTile(out, tile, 0); // 
			}
	
			try { Thread.sleep(50); } catch (InterruptedException e) { e.printStackTrace(); }
	
			highlightedTiles.clear();
			attackTiles.clear();
		}
	}
	
	public void addStunnedUnit(Unit unit) {     //about the spell Beamshock
		stunnedUnits.add(unit);
	}

	public void resetStunnedUnits() {             //about the spell Beamshock
		Set<Unit> unitsToRemove = new HashSet<>();

		for (Unit unit : stunnedUnits) {
			unit.reduceStunnedTurns();
			if (!unit.isStunned()) {
				unitsToRemove.add(unit);
			}
		}

		stunnedUnits.removeAll(unitsToRemove);
	}

	public Unit placeUnit(ActorRef out, GameState gameState, Tile clickedTile, Card selectedCard) {
		String unitConfig = selectedCard.getUnitConfig();
		int id = selectedCard.getId();

		// Generate a unique ID for the unit
		int uniqueId = gameState.generateUniqueUnitId();

		// Use createUnit method to create the unit
		Unit unit = createUnit(out, clickedTile, unitConfig);
		if(unit != null){
			if(!unit.getUnitName().contains("Saberspine Tiger")){
				notMoveAndAttack.add(unit);
			}

			unit.getPlayer().setMana(unit.getPlayer().getMana() - selectedCard.getManacost());
			if(unit.getPlayer() == gameState.getHumanPlayer()){
				BasicCommands.setPlayer1Mana(out, unit.getPlayer());
			} else {
				BasicCommands.setPlayer2Mana(out, unit.getPlayer());
			}

			gameState.clearHighlight(out);
			// Remove the card from hand
			Player currentPlayer = gameState.getCurrentPlayer();
			currentPlayer.getCardsOnHand().remove(selectedCard);

			// Redraw remaining cards after removing the card in previous step
			if(currentPlayer == gameState.getHumanPlayer()) {
				gameState.displayPlayersCard(out, currentPlayer);
			}
			
			unit.OpeningGambitAbility(out, gameState, clickedTile);

			List<Unit> neighbourUnits = unit.getNeighbourUnits(gameState, clickedTile);
			for(Unit neighbour : neighbourUnits){
				if(neighbour.hasProvokeAbility()){
					Tile tile = neighbour.getTileFromUnit(gameState);
					neighbour.applyProvokeAbility(tile, gameState);	
				}
			}

			if(unit.hasProvokeAbility()){
				unit.applyProvokeAbility(clickedTile, this);
				}
				
				checkIfPlayerDeckEmpty(out, gameState);	
			}
		
		return unit;
	}

	//Checks if Player who's turn it is loses when they have no card in hand or deck
	public void checkIfPlayerDeckEmpty(ActorRef out, GameState gameState) {
		List<Card> playerDeck; 
		List<Card> playerHand;
		
		//Get whose turn it is and check if their deck is empty
		if (gameState.getPlayer1Turn() == true ) {
			System.out.println("Getting humanPlayer's Deck & Hand");
			playerDeck = gameState.getHumanPlayer().getCardDeck();
			playerHand = gameState.getHumanPlayer().getCardsOnHand();
			if (playerDeck.isEmpty() && playerHand.isEmpty()) {
				System.out.println("\nHuman player has no cards on hand or in their deck. \nGame Over: the human player has lost!");
				gameState.setGameOver(true);
				BasicCommands.addPlayer1Notification(out, "Empty hand & deck! AI Player wins", 5);
			}
		} else if (gameState.getPlayer1Turn() == false) {
			System.out.println("Getting humanPlayer's Deck & Hand");
			playerDeck = gameState.getAiPlayer().getCardDeck();
			playerHand = gameState.getHumanPlayer().getCardsOnHand();
			if (playerDeck.isEmpty() && playerHand.isEmpty()) {
				System.out.println("\nAI player has no cards on hand or in their deck. \nGame Over: the AI player has lost!");
				gameState.setGameOver(true);
				BasicCommands.addPlayer1Notification(out, "Empty hand & deck! Human Player wins", 5);
			}
		}	
	}


/**
 * Highlight the castable targets of different spell cards.
 * - Horn of the Forsaken: Highlight only the Tile where your Avatar is.
 * - Wraithling Swarm, Dark Terminus: Highlight "all tiles containing enemy units".
 */
public void highlightSpellTargets(ActorRef out, Card selectedCard) {
    // 1. Clear all previous highlights
    clearHighlight(out);

    // 2. Determine the name of the card and execute the corresponding highlighting logic
	if (selectedCard.getCardname().equals("Horn of the Forsaken")) {
		Unit myAvatar = this.getCurrentPlayer().getAvatar();
		if (myAvatar != null) {
			Tile avatarTile = myAvatar.getTileFromUnit(this);
			if (avatarTile != null) {
				BasicCommands.drawTile(out, avatarTile, 2);
				addHighlightedTile(avatarTile);
			}
		}

    } else if (selectedCard.getCardname().equals("Dark Terminus")) {
        // Highlight all Tiles containing enemy units.
        for (int i = 0; i < GameState.COLS; i++) {
            for (int j = 0; j < GameState.ROWS; j++) {
                Tile tile = GameState.tileGrid[i][j];
                Unit unit = tile.getUnitFromTile();
                // Highlight if there is a unit on the Tile that is not the current player's unit
                if (unit != null && !unit.isAiAvatar() && unit.getPlayer() != this.getCurrentPlayer()) {
                    BasicCommands.drawTile(out, tile, 2);
                    addHighlightedTile(tile);
                }
            }
        }	
	}
  }
  
  //Highlight the 8 Tiles around all your units as the legal location for summoned units.
  public void highlightSummonTiles(ActorRef out) {
    // 1. Remove previous highlights to avoid overlays
    clearHighlight(out);

    // 2. Get the current player
    Player currentPlayer = getCurrentPlayer();

    // 3. Traverse the board to find your own units
    for (int i = 0; i < COLS; i++) {
        for (int j = 0; j < ROWS; j++) {
            Tile tile = tileGrid[i][j];
            Unit unit = tile.getUnitFromTile();

            // 4. If there is a unit of your side on the Tile, you will be able to use it.
            if (unit != null && unit.getPlayer() == currentPlayer) {
                // 5. Obtain 8 locations around the unit
                int[][] directions = {
                    {-1, -1}, {0, -1}, {1, -1}, 
                    {-1, 0},  {1, 0},          
                    {-1, 1},  {0, 1},  {1, 1}   
                };

                for (int[] dir : directions) {
                    int newX = i + dir[0];
                    int newY = j + dir[1];

                    // 6. Make sure the coordinates are legal and the Tile is empty.
					if (newX >= 0 && newX < COLS && newY >= 0 && newY < ROWS) {  // Add explicit boundary judgements
						Tile adjacentTile = tileGrid[newX][newY];
						if (adjacentTile.getUnitFromTile() == null) {
							BasicCommands.drawTile(out, adjacentTile, 1);
							addHighlightedTile(adjacentTile);
						}
					}
                    }
                }
            }
        }
    }

	// This method summons a new Wraithling unit onto a chosen tile 
	public Unit summonWraithling(ActorRef out, Tile wrathlingTile) {
		String configFile = StaticConfFiles.u_wraithling;
		Unit newWraithling = createUnit(out, wrathlingTile, configFile);
		return newWraithling;
	}

	public void removeDeadUnit(ActorRef out, Unit unit, Tile tile) {
		if (unit != null && unit.getHealth() <= 0) {

			if(unit.isMartyr()){
				BasicCommands.playEffectAnimation(out, EffectAnimation.inmolation(), tile);	
			}
			else {
				try {Thread.sleep(BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.death));} catch (InterruptedException e) {e.printStackTrace();}
			}
			if(unit.hasProvokeAbility()){
				unit.removeProvokeAbility(unit.getTileFromUnit(this), this);
			}
			tile.setUnitToTile(null);
			BasicCommands.drawTile(out, tile, 0);
			unit.getPlayer().removeUnit(this,unit);
			BasicCommands.deleteUnit(out, unit);
			try { Thread.sleep(200); } catch (InterruptedException e) { e.printStackTrace(); }
			BasicCommands.addPlayer1Notification(out, "⚔️ The unit has been extinguished!", 2);
			try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
			if (unit.isHumanAvatar() || unit.isAiAvatar()) {
				checkForWin(out, unit);
			}
			unit.incrementGlobalDeadWatched();
			unit.deadWatchedAbilities(out, unit, this);
		}
	}
}





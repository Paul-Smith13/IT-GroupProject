package commands;

import akka.actor.ActorRef;
import actors.GameActor;
import events.EndTurnClicked;
import structures.GameState;
import structures.basic.*;
import structures.basic.Card;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.*;

// AICommands handles all AI decision-making, including unit movement, attacks, and card play.
public class AICommands {
    private final GameActor aiActor;
    private final GameState gameState;
    private final Random rand = new Random();
	private List<Unit> aiUnits = new ArrayList<>();
    private List<Unit> humanUnits = new ArrayList<>();

    public AICommands(GameActor aiActor, GameState gameState) {
        this.aiActor = aiActor;
        this.gameState = gameState;
    }

	//Main AI execution logic for its turn.
    public void executeAiTurn(ActorRef out, GameState gameState) {
		aiUnits = gameState.getAiPlayer().getAiUnits(gameState);
		humanUnits = gameState.getHumanPlayer().getHumanUnits(gameState);
        System.out.println("Current AI units: " + aiUnits);
        System.out.println("Current Human units: " + humanUnits);

        aiMoveAndAttack(out);
		playCards(out);
        endTurn(out);
    }

	//AI moves and attacks with its units.
    private void aiMoveAndAttack(ActorRef out) {
		for (Unit aiUnit : aiUnits) {
            if (gameState.hasUnitMoved(aiUnit) && gameState.hasUnitAttacked(aiUnit)) {
		        continue;
            }

			if(aiUnit.getUnitName().equals("Young Flamewing")){
				playYoungFlameWing(out, aiUnit);
			}

            else{
                Unit bestTarget = getClosestEnemy(aiUnit, humanUnits);
                if (bestTarget == null) {
                    continue;
                }

				if(aiUnit.getAttack() == 0){
					moveToBestPosition(out, aiUnit);
				}

                Tile aiTile = aiUnit.getTileFromUnit(gameState);
                Tile targetTile = bestTarget.getTileFromUnit(gameState);
                int distance = getTileDistance(aiTile, targetTile);

                if (distance == 1) {
                    aiUnit.attack(out, aiTile, targetTile, gameState);
                } else if (distance == 2 || distance == 3) {
                    aiUnit.moveAndAttack(out, aiTile, targetTile, gameState);
                } else {
                    moveToBestPosition(out, aiUnit);
                }
            }
        }
    }

    /**
     * Returns the closest enemy to a given AI unit.
     */
    private Unit getClosestEnemy(Unit aiUnit, List<Unit> enemyUnits) {
        Unit closestEnemy = null;
        int minDistance = Integer.MAX_VALUE;

        for (Unit enemy : enemyUnits) {
            int distance = getTileDistance(aiUnit.getTileFromUnit(gameState), enemy.getTileFromUnit(gameState));

            if (distance < minDistance) {
                minDistance = distance;
                closestEnemy = enemy;
            }
			//Prioritizes Rock Pulveriser
			if (enemy.getUnitName().equals("Rock Pulveriser")){
				return enemy;
			}
        }
        return closestEnemy;
    }

	private void playYoungFlameWing(ActorRef out, Unit youngFlameWing){
        Unit target = null;

        // Look for enemy with less health than Young FlameWing's attack and approachable, attack the highest attack one
        List<Unit> weakEnemies = new ArrayList<>();

		for (Unit enemy : humanUnits) {
            List<Tile> adjacentTiles = enemy.getTileFromUnit(gameState).getAdjacentTiles(gameState);
			if (enemy.getHealth() <= youngFlameWing.getAttack() && !adjacentTiles.isEmpty()) {
                weakEnemies.add(enemy);
			} 

            target = getHighestAttackUnit(weakEnemies);
		}

        // If found no enemy with less health and approachable, attack highest attack enemy with less health
        if (target == null) {
            target = getHighestAttackUnit(humanUnits);
        }

        if (target != null) {
            System.out.println("Young Flamewing targeting " + target);
            List<Tile> adjacentTiles = target.getTileFromUnit(gameState).getAdjacentTiles(gameState);
            Tile currentTile = youngFlameWing.getTileFromUnit(gameState);

            for (Tile targetTile : adjacentTiles) {
                if (!targetTile.isOccupied()) {

                    System.err.println("Young Flamewing approaching " + target);
                    youngFlameWing.moveUnit(out, currentTile, targetTile, gameState);
                    System.err.println("Young Flamewing attacking " + target);
                    youngFlameWing.attack(out, targetTile, target.getTileFromUnit(gameState), gameState);
                    break;
                }
            }
        }
	}

	//AI picks and plays cards based on card-priority and available mana.
    private void playCards(ActorRef out) {
        Player aiPlayer = gameState.getAiPlayer();
        List<Card> cardsOnHand = new ArrayList<>(aiPlayer.getCardsOnHand());
        String[] priority = {"Beamshock", "Sundrop Elixir", "Truestrike", "Silverguard Squire", "Swamp Entangler", 
                            "Skyrock Golem", "Saberspine Tiger", "Silverguard Knight", "Young Flamewing", "Ironcliff Guardian"};

        for (String cardName : priority) {
            for (Card card : cardsOnHand) {
				if (cardName.equals("Silverguard Squire") && !shouldUseSilverguardSquire(gameState)) {
					continue;
				}
                if (card.getCardname().equals(cardName) && card.getManacost() <= aiPlayer.getMana()) {
                    if (card.isCreature()) {
                        if (aiUnits.size() <= humanUnits.size()-1 && canPlaceUnit(gameState)) {
                            Unit newUnit = playUnitCard(out, card);

                            // If unit placed is Saberspine Tiger, let it move and attack right after summoned (Rush ability)
                            if (card.getCardname().equals("Saberspine Tiger")) {
                                playSaberspineTiger(out, newUnit);
                            }

                            try { Thread.sleep(150); } catch (InterruptedException e) { e.printStackTrace(); }
                        }
                    } else {
                        playSpellCard(out, card);
                        try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
                    }
                }
            }
        }
    }


    private void playSaberspineTiger(ActorRef out, Unit saberspineTiger) {
        System.out.println("Saberspine Tiger is using Rush for its first turn");
        
        Unit bestTarget = getClosestEnemy(saberspineTiger, humanUnits);
        if (bestTarget == null) {
            return;
        }

        Tile currentTile = saberspineTiger.getTileFromUnit(gameState);
        Tile targetTile = bestTarget.getTileFromUnit(gameState);
        int distance = getTileDistance(currentTile, targetTile);

        if (distance == 1) {
            saberspineTiger.attack(out, currentTile, targetTile, gameState);
        } else if (distance == 2 || distance == 3) {
            saberspineTiger.moveAndAttack(out, currentTile, targetTile, gameState);
        } else {
            moveToBestPosition(out, saberspineTiger);
        }
    }
        

	// Check before casting Silverguard Squire, returns true only if there is at least one unit on the right or left of AI avatar
	private boolean shouldUseSilverguardSquire(GameState gameState) {
		Tile avatarTile = gameState.getAiAvatar().getTileFromUnit(gameState);
		int[][] dirs = {{ 1, 0 }, { -1, 0 }};	// Right (col + 1), Left (col - 1)

		for (int[] dir : dirs) {
			int newX = avatarTile.getTilex() + dir[0];
			int newY = avatarTile.getTiley() + dir[1];
			
			if (gameState.isValidTile(newX, newY)) {
				Tile tile = GameState.tileGrid[newX][newY];
				if (tile.getUnitFromTile() != null && tile.getUnitFromTile().getPlayer() == gameState.getAiPlayer()) {
					return true;
				}
			}
		}
		
		return false;
	}

	//Ends AI's turn.
    private void endTurn(ActorRef out) {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode message = objectMapper.createObjectNode();
        message.put("messagetype", "endturnclicked");
        new EndTurnClicked().processEvent(out, gameState, message);
    }

	//AI places a unit onto the board at an optimal position.
    private Unit playUnitCard(ActorRef out, Card card) {
        List<Tile> validTiles = getValidPlacementTiles();

        if (validTiles.isEmpty()) {
            return null;
        }
        
        Tile tile = validTiles.get(rand.nextInt(validTiles.size()));
        Unit newUnit = gameState.placeUnit(out, gameState, tile, card);
        
        return newUnit;
    }

	//AI plays a spell card if a valid target is available.
    private boolean playSpellCard(ActorRef out, Card card) {
        List<Unit> potentialTargets;
        Unit targetUnit = null;

        if (card.getCardname().equals("Sundrop Elixir")) {
            potentialTargets = gameState.getAiPlayer().getAllUnits();
            for (Unit unit : potentialTargets) {
                if (unit.getHealth() <= unit.getMaxHealth() - 5) {
                    targetUnit = unit;
                    break;
                }
            }
        } else if (card.getCardname().equals("Truestrike")) {
            potentialTargets = gameState.getHumanPlayer().getAllUnits();
            if (!potentialTargets.isEmpty()) {
                targetUnit = potentialTargets.get(rand.nextInt(potentialTargets.size()));
            }
        } else if (card.getCardname().equals("Beamshock")) {
            // Apply Beamshock (Stun) enemy target not avatar and with highest attack

            potentialTargets = gameState.getHumanPlayer().getAllUnits();
            System.out.println("Potential targets: " + potentialTargets);

            // Remove Human avatar from potentialTargets (condition of Beamshock)
            for (Unit target : potentialTargets) {
                if (target.isHumanAvatar()) {
                    potentialTargets.remove(target);
                    break;
                }
            }
            System.out.println("Removed human avatar from potential targets.");
            System.out.println("Updated potential targets: " + potentialTargets);

            // Apply Beamshock on enemy with highest attack 
            targetUnit = getHighestAttackUnit(potentialTargets);
        }

        if (targetUnit != null) {
            return card.applySpell(out, gameState, targetUnit);
        }
        return false;
    }


    // Returns the unit with highest attack in the input list, returns null if the input list is empty
    private Unit getHighestAttackUnit(List<Unit> units) {
        if (units.isEmpty()) {
            return null;
        }

        Unit highestAttackUnit = new Unit();
        highestAttackUnit.setAttack(0);
        for (Unit unit : units) {
            if (unit.getAttack() > highestAttackUnit.getAttack()) {
                highestAttackUnit = unit;
            }
        }
        return highestAttackUnit;
    }

	//Moves AI unit to the best available position based on safety and attack potential.
    private void moveToBestPosition(ActorRef out, Unit aiUnit) {
        List<Tile> validTiles = getValidPlacementTiles();
        if (validTiles.isEmpty()) {
            return;
        }

        Tile bestTile = validTiles.get(rand.nextInt(validTiles.size()));
        Tile currentTile = aiUnit.getTileFromUnit(gameState);

        if (!bestTile.equals(currentTile)) {
            aiUnit.moveUnit(out, currentTile, bestTile, gameState);
        }
    }

	//Gets valid tiles for AI to place units.
    private List<Tile> getValidPlacementTiles() {
        List<Tile> validTiles = new ArrayList<>();
        for (Tile[] row : GameState.tileGrid) {
            for (Tile tile : row) {
                if (tile.isValidToPlaceUnit(gameState)) {
                    validTiles.add(tile);
                }
            }
        }
        return validTiles;
    }

	//Checks if AI can place a unit.
    private boolean canPlaceUnit(GameState gameState) {
        return !getValidPlacementTiles().isEmpty();
    }

	//Calculates the distance between two tiles.
    private int getTileDistance(Tile tile1, Tile tile2) {
        return Math.abs(tile1.getTilex() - tile2.getTilex()) + Math.abs(tile1.getTiley() - tile2.getTiley());
    }
}


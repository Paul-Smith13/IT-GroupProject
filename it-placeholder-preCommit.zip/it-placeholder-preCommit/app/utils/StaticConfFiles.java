package utils;

/**
 * This is a utility class that just has short-cuts to the location of various
 * config files. 
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class StaticConfFiles {

	// Board Pieces
	public final static String tileConf = "conf/gameconfs/tile.json";
	public final static String gridConf = "conf/gameconfs/grid.json";
	
	// Avatars
	public final static String humanAvatar = "conf/gameconfs/avatars/avatar1.json";
	public final static String aiAvatar = "conf/gameconfs/avatars/avatar2.json";
	
	// Tokens
	public final static String wraithling = "conf/gameconfs/units/wraithling.json";
	
	// Effects
	public final static String f1_inmolation = "conf/gameconfs/effects/f1_inmolation.json";
	public final static String f1_buff = "conf/gameconfs/effects/f1_buff.json";
	public final static String f1_martyrdom = "conf/gameconfs/effects/f1_martyrdom.json";
	public final static String f1_projectiles = "conf/gameconfs/effects/f1_projectiles.json";
	public final static String f1_summon = "conf/gameconfs/effects/f1_summon.json";
	public final static String f1_wraithlingsummon = "conf/gameconfs/effects/f1_wraithsummon.json";

	// Deck 1 Cards
	public final static String c_bad_omen = "conf/gameconfs/cards/1_1_c_u_bad_omen.json";
	public final static String c_gloom_chaser = "conf/gameconfs/cards/1_3_c_u_gloom_chaser.json";
	public final static String c_rock_pulveriser = "conf/gameconfs/cards/1_7_c_u_rock_pulveriser.json";
	public final static String c_shadow_watcher = "conf/gameconfs/cards/1_4_c_u_shadow_watcher.json";
	public final static String c_nightsorrow_assassin = "conf/gameconfs/cards/1_6_c_u_nightsorrow_assassin.json";
	public final static String c_bloodmoon_priestess = "conf/gameconfs/cards/1_9_c_u_bloodmoon_priestess.json";
	public final static String c_shadowdancer = "conf/gameconfs/cards/1_a1_c_u_shadowdancer.json";
	public final static String c_horn_of_the_forsaken = "conf/gameconfs/cards/1_2_c_s_hornoftheforsaken.json";
	public final static String c_wraithling_swarm = "conf/gameconfs/cards/1_5_c_s_wraithling_swarm.json";
	public final static String c_dark_terminus = "conf/gameconfs/cards/1_8_c_s_dark_terminus.json";
	
	// Deck 1 Units
	public final static String u_bad_omen = "conf/gameconfs/units/bad_omen.json"; 
	public final static String u_bloodmoon_priestess = "conf/gameconfs/units/bloodmoon_priestess.json";
	public final static String u_gloom_chaser = "conf/gameconfs/units/gloom_chaser.json";
	public final static String u_nightsorrow_assassin = "conf/gameconfs/units/nightsorrow_assassin.json";
	public final static String u_rock_pulveriser = "conf/gameconfs/units/rock_pulveriser.json";
	public final static String u_shadow_watcher = "conf/gameconfs/units/shadow_watcher.json";
	public final static String u_shadowdancer = "conf/gameconfs/units/shadowdancer.json";
	public final static String u_wraithling = "conf/gameconfs/units/wraithling.json";


	// Deck 2 Cards
	public final static String c_swamp_entangler = "conf/gameconfs/cards/2_2_c_u_swamp_entangler.json"; 
	public final static String c_silverguard_squire = "conf/gameconfs/cards/2_7_c_u_silverguard_squire.json"; 
	public final static String c_skyrock_golem = "conf/gameconfs/cards/2_1_c_u_skyrock_golem.json"; 
	public final static String c_saberspine_tiger = "conf/gameconfs/cards/2_4_c_u_saberspine_tiger.json"; 
	public final static String c_silverguard_knight = "conf/gameconfs/cards/2_3_c_u_silverguard_knight.json"; 
	public final static String c_young_flamewing = "conf/gameconfs/cards/2_6_c_u_young_flamewing.json"; 
	public final static String c_ironcliff_guardian = "conf/gameconfs/cards/2_8_c_u_ironcliff_guardian.json"; 
	public final static String c_sundrop_elixir = "conf/gameconfs/cards/2_9_c_s_sundrop_elixir.json"; 	// H-1, A-1, C1
	public final static String c_truestrike = "conf/gameconfs/cards/2_a1_c_s_truestrike.json"; 			// H-1, A-1, C1
	public final static String c_beamshock = "conf/gameconfs/cards/2_5_c_s_beamshock.json"; 			// H-1, A-1, C0

	// Deck 2 Units
	public final static String u_ironcliff_guardian = "conf/gameconfs/units/ironcliff_guardian.json"; 	// H3, A10, C5
	public final static String u_saberspine_tiger = "conf/gameconfs/units/saberspine_tiger.json"; 		// H2, A3, C3
	public final static String u_silverguard_knight = "conf/gameconfs/units/silverguard_knight.json"; 	// H5, A1, C3
	public final static String u_silverguard_squire = "conf/gameconfs/units/silverguard_squire.json"; 	// H1, A1, C1
	public final static String u_skyrock_golem = "conf/gameconfs/units/skyrock_golem.json"; 			// H2, A4, C2
	public final static String u_swamp_entangler = "conf/gameconfs/units/swamp_entangler.json"; 		// H3, A0, C1
	public final static String u_young_flamewing = "conf/gameconfs/units/young_flamewing.json"; 		// H4, A5, C4


}

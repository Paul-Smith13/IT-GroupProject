package demo;

import actors.GameActor;
import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.*;
import utils.BasicObjectBuilders;
import utils.OrderedCardLoader;
import utils.StaticConfFiles;

public class TestCommands {
    public static final int INITIAL_HEALTH = 20;
    public static final int INITIAL_MANA = 2;

    public static void executeDemo(ActorRef out, GameState gameState) {
        gameState.drawGrid(out);
        gameState.loadUnitStats();
        gameState.setGameOver(false);
        
        gameState.initialiseHumanPlayer(out, INITIAL_HEALTH, INITIAL_MANA);
        gameState.initialiseAiPlayer(out, INITIAL_HEALTH, INITIAL_MANA);

        gameState.startHumanTurn(out);
    }
}

